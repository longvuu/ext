load("config.js");

function toAbsoluteUrl(url) {
    if (!url) return "";
    if (url.startsWith("http")) return url;
    let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
    return baseUrl + (url.startsWith("/") ? url : "/" + url);
}

function buildPagedUrl(url, page) {
    let cleanUrl = url || "";
    cleanUrl = cleanUrl.replace(/([?&])page=\d+/i, "").replace(/[?&]$/, "");
    return cleanUrl + (cleanUrl.indexOf('?') > -1 ? "&" : "?") + "page=" + page;
}

function execute(url, page) {
    if (!page) page = '1';
    let requestUrl = buildPagedUrl(url, page);
    
    let response = fetch(requestUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return Response.error("Không thể tải trang web: " + requestUrl);
    }
    
    let doc = response.html();
    let books = [];
    
    // Target card links only to avoid menu/search anchors that also use the same classes.
    let mangaLinks = doc.select("a[href*='/truyen-hentai/'], a[href*='/truyen/']");
    
    mangaLinks.forEach(mangaLink => {
        try {
            let href = mangaLink.attr("href");
            if (!href || href.indexOf("/truyen") === -1) return;
            
            let titleElement = mangaLink.select("h3, h2, h1").first();
            let name = titleElement ? titleElement.text().trim() : "";
            
            if (!name || name.length < 2) return;
            
            href = toAbsoluteUrl(href);
            
            let cover = "";
            
            let imgTag = mangaLink.select("img").first();
            if (imgTag) {
                cover = imgTag.attr("src");
                if (!cover) cover = imgTag.attr("data-src");
                if (!cover) cover = imgTag.attr("data-lazy-src");
                if (!cover) cover = imgTag.attr("srcset");
                if (!cover) cover = imgTag.attr("data-srcset");
                if (cover && cover.indexOf(',') > -1) {
                    cover = cover.split(',')[0].trim().split(' ')[0];
                }
            }
            
            if (!cover) {
                let styleHolder = mangaLink.select("[style*='background-image']").first();
                if (styleHolder) {
                    let style = styleHolder.attr("style");
                    let match = style ? style.match(/background-image:\s*url\(['"]?([^'")\s]+)['"]?\)/i) : null;
                    if (match && match[1]) cover = match[1].trim();
                }
            }
            
            cover = toAbsoluteUrl(cover);
            
            let alreadyExists = false;
            for (let i = 0; i < books.length; i++) {
                if (books[i].name === name || books[i].link === href) {
                    alreadyExists = true;
                    break;
                }
            }
            
            if (!alreadyExists && href && name) {
                books.push({
                    name: name,
                    link: href,
                    cover: cover,
                    description: "",
                    host: BASE_URL,
                    author: ""
                });
            }
        } catch (e) {
        }
    });

    let nextPage = "";
    let currentPageNum = parseInt(page);
    if (!isNaN(currentPageNum) && books.length >= 40) {
        nextPage = (currentPageNum + 1).toString();
    }

    return Response.success(books, nextPage);
}
