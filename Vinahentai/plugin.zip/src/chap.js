load('config.js');

function execute(url) {
    var browser = null;
    
    try {
        let imgs = [];
        let response = fetch(url);
        if (!response || !response.ok) {
            return Response.error("Không tải được trang chương");
        }

        let doc = response.html();
        let raw = getRawText(response, doc);

        collectFromDoc(doc, imgs);
        collectFromRaw(raw, imgs);
        collectFromReactRouterStream(raw, imgs);

        if (imgs.length > 1) {
            imgs.sort((a, b) => extractPageNumber(a) - extractPageNumber(b));
            return Response.success(imgs);
        }

        // Browser fallback when SSR parse yields none or only preload image.
        try {
            browser = Engine.newBrowser();
            browser.setUserAgent(UserAgent.chrome());
            browser.launch(url, 8);
            browser.callJs("", 2200);

            // Inject extractor: collect from DOM + scripts + React stream/runtime into #__vh_urls.
            browser.callJs(
                "(function(){"
                + "try {"
                + "  var found = [];"
                + "  function add(u){"
                + "    if(!u) return;"
                + "    u = String(u).replace(/\\\\u002F/gi,'/').replace(/\\\\\//g,'/').trim();"
                + "    if(u.indexOf('/manga-images/') === 0) u = 'https://cdn.vinahentai.icu' + u;"
                + "    if(u.indexOf('manga-images/') === 0) u = 'https://cdn.vinahentai.icu/' + u;"
                + "    if(/^https?:\\/\\//i.test(u) && /\\/manga-images\\//i.test(u) && /\\.(jpg|jpeg|png|webp)(\\?|$)/i.test(u)) {"
                + "      if(found.indexOf(u) < 0) found.push(u);"
                + "    }"
                + "  }"
                + "  var imgs = document.querySelectorAll('img');"
                + "  for(var i=0;i<imgs.length;i++){"
                + "    add(imgs[i].getAttribute('src'));"
                + "    add(imgs[i].getAttribute('data-src'));"
                + "    add(imgs[i].getAttribute('data-lazy-src'));"
                + "    var ss = imgs[i].getAttribute('srcset') || imgs[i].getAttribute('data-srcset') || '';"
                + "    if(ss){ add(ss.split(',')[0].trim().split(' ')[0]); }"
                + "  }"
                + "  var links = document.querySelectorAll('link[rel=preload][as=image]');"
                + "  for(var j=0;j<links.length;j++){ add(links[j].getAttribute('href')); }"
                + "  var scripts = document.querySelectorAll('script');"
                + "  var all = '';"
                + "  for(var k=0;k<scripts.length;k++){ all += '\\n' + (scripts[k].textContent || ''); }"
                + "  var norm = all.replace(/\\\\u002F/gi,'/').replace(/\\\\\//g,'/');"
                + "  var m = norm.match(/https?:\\/\\/[^\"'\\s,]+\\/manga-images\\/[^\"'\\s,]+\\.(jpg|jpeg|png|webp)(\\?[^\"'\\s,]*)?/gi) || [];"
                + "  for(var x=0;x<m.length;x++){ add(m[x]); }"
                + "  var section = norm.match(/\"contentUrls\"([\\s\\S]*?)\"mangaId\"/i);"
                + "  if(section && section[1]){"
                + "    var m2 = section[1].match(/https?:\\/\\/[^\"'\\s,]+\\/manga-images\\/[^\"'\\s,]+\\.(jpg|jpeg|png|webp)(\\?[^\"'\\s,]*)?/gi) || [];"
                + "    for(var y=0;y<m2.length;y++){ add(m2[y]); }"
                + "  }"
                + "  var holder = document.getElementById('__vh_urls');"
                + "  if(!holder){"
                + "    holder = document.createElement('script');"
                + "    holder.id = '__vh_urls';"
                + "    holder.type = 'application/json';"
                + "    document.body.appendChild(holder);"
                + "  }"
                + "  holder.textContent = JSON.stringify(found);"
                + "} catch(e) {}"
                + "})();",
                1600
            );

            let doc2 = browser.html();
            collectFromDoc(doc2, imgs);
            collectFromRaw(doc2.html() || "", imgs);

            // Read injected extracted urls.
            try {
                let payload = doc2.select("#__vh_urls").text();
                if (payload) {
                    let arr = JSON.parse(payload);
                    if (arr && arr.forEach) {
                        arr.forEach(u => collectImageCandidate(u, imgs));
                    }
                }
            } catch (ignorePayload) {}
        } catch (ignoreBrowserError) {
            // keep final error below
        } finally {
            if (browser) {
                try { browser.close(); } catch (closeError) {}
                browser = null;
            }
        }

        if (imgs.length > 0) {
            imgs.sort((a, b) => extractPageNumber(a) - extractPageNumber(b));
            return Response.success(imgs);
        }

        return Response.error("Không tìm thấy nội dung chương");
        
    } catch (e) {
        if (browser) {
            try {
                browser.close();
            } catch (closeError) {}
        }
        return Response.error("Lỗi tải chapter: " + e.message);
    }
}

function getRawText(response, doc) {
    let raw = "";

    if (response) {
        if (response.text) {
            try { raw = response.text() || ""; } catch (ignore1) {}
        }
        if ((!raw || raw.length < 50) && response.body) {
            try { raw = response.body() || ""; } catch (ignore2) {}
        }
        if ((!raw || raw.length < 50) && response.string) {
            try { raw = response.string() || ""; } catch (ignore3) {}
        }
        if ((!raw || raw.length < 50) && response.toString) {
            try { raw = String(response.toString() || ""); } catch (ignore4) {}
        }
    }

    if ((!raw || raw.length < 50) && doc) {
        try { raw = doc.html() || ""; } catch (ignore5) {}
    }

    if ((!raw || raw.length < 50) && doc) {
        try {
            let scripts = [];
            doc.select("script").forEach(sc => {
                scripts.push(sc.html() || "");
                scripts.push(sc.text() || "");
            });
            raw = scripts.join("\n");
        } catch (ignore6) {}
    }

    return raw || "";
}

function collectFromDoc(doc, imgs) {
    if (!doc) return;

    let imgElements = doc.select("img");
    imgElements.forEach(img => {
        collectImageCandidate(img.attr("src"), imgs);
        collectImageCandidate(img.attr("data-src"), imgs);
        collectImageCandidate(img.attr("data-lazy-src"), imgs);
        collectImageCandidate(firstSrcFromSrcset(img.attr("srcset")), imgs);
        collectImageCandidate(firstSrcFromSrcset(img.attr("data-srcset")), imgs);
    });

    // React SSR preloads chapter pages in head via link preload image.
    let preload = doc.select("link[rel='preload'][as='image']");
    preload.forEach(link => {
        collectImageCandidate(link.attr("href"), imgs);
    });
}

function collectFromRaw(raw, imgs) {
    if (!raw) return;

    // Normalized text catches escaped JSON URLs like https:\/\/cdn... and \u002F separators.
    let normalized = raw.replace(/\\u002F/gi, "/").replace(/\\\//g, "/");

    let matches = normalized.match(/https?:\/\/cdn\.vinahentai\.icu\/manga-images\/[^"'\s<>]+\.(jpg|jpeg|png|webp)(\?[^"'\s<>]*)?/gi);
    if (matches && matches.length > 0) {
        matches.forEach(function (u) { collectImageCandidate(u, imgs); });
    }

    // Some chunks may keep escaped quote wrappers around URLs.
    let quotedMatches = normalized.match(/\"https?:\/\/[^\"\s,]+\/manga-images\/[^\"\s,]+\.(jpg|jpeg|png|webp)(\?[^\"\s,]*)?\"/gi);
    if (quotedMatches && quotedMatches.length > 0) {
        quotedMatches.forEach(function (u) {
            collectImageCandidate(u.replace(/^\\\"|\\\"$/g, ""), imgs);
        });
    }

    // Also capture relative image paths to manga-images.
    let relMatches = normalized.match(/(?:\"|')?(\/manga-images\/[^"'\s<>]+\.(jpg|jpeg|png|webp)(\?[^"'\s<>]*)?)/gi);
    if (relMatches && relMatches.length > 0) {
        relMatches.forEach(function (u) { collectImageCandidate(u, imgs); });
    }

    // High-confidence extraction from chapter contentUrls section in React stream.
    // Format is often: "contentUrls",[indexes],"https://...","https://...",...,"mangaId"
    let sectionMatch = normalized.match(/"contentUrls"([\s\S]*?)"mangaId"/i);
    if (sectionMatch && sectionMatch[1]) {
        let section = sectionMatch[1];
        let sectionUrls = section.match(/https?:\/\/[^"'\s,]+\/manga-images\/[^"'\s,]+\.(jpg|jpeg|png|webp)(\?[^"'\s,]*)?/gi);
        if (sectionUrls && sectionUrls.length > 0) {
            sectionUrls.forEach(function (u) { collectImageCandidate(u, imgs); });
        }
    }
}

function collectFromReactRouterStream(raw, imgs) {
    if (!raw) return;

    // React Router streams data in multiple enqueue("...") script chunks.
    let streamParts = [];
    let re = /streamController\.enqueue\("([\s\S]*?)"\);/g;
    let m;
    while ((m = re.exec(raw)) !== null) {
        let chunk = m[1] || "";
        chunk = chunk
            .replace(/\\u002F/gi, "/")
            .replace(/\\\//g, "/")
            .replace(/\\n/g, "\n")
            .replace(/\\"/g, '"')
            .replace(/\\\\/g, "\\");
        streamParts.push(chunk);
    }

    if (streamParts.length === 0) return;

    let streamText = streamParts.join("");
    collectFromRaw(streamText, imgs);
}

function firstSrcFromSrcset(srcset) {
    if (!srcset) return "";
    let first = srcset.split(",")[0] || "";
    first = first.trim();
    if (!first) return "";
    return first.split(" ")[0].trim();
}

function collectImageCandidate(rawUrl, imgs) {
    let imageUrl = normalizeImageUrl(rawUrl);
    if (isChapterImage(imageUrl) && !imgs.includes(imageUrl)) {
        imgs.push(imageUrl);
    }
}

function normalizeImageUrl(imageUrl) {
    if (!imageUrl) return "";
    imageUrl = ("" + imageUrl).trim();
    imageUrl = imageUrl.replace(/\\u002F/gi, "/").replace(/\\\//g, "/");

    // Handle wrapped/quoted strings in data attributes.
    imageUrl = imageUrl.replace(/^['\"]+|['\"]+$/g, "");

    // Handle proxied URLs like /_next/image?url=https%3A%2F%2Fcdn...
    let encoded = imageUrl.match(/[?&]url=([^&]+)/i);
    if (encoded && encoded[1]) {
        try {
            imageUrl = decodeURIComponent(encoded[1]);
        } catch (ignore) {}
    }

    if (imageUrl.startsWith("data:")) return "";
    if (imageUrl.indexOf("/manga-images/") === 0) return "https://cdn.vinahentai.icu" + imageUrl;
    if (imageUrl.indexOf("manga-images/") === 0) return "https://cdn.vinahentai.icu/" + imageUrl;
    if (imageUrl.startsWith("//")) return "https:" + imageUrl;
    if (imageUrl.startsWith("http")) return imageUrl;
    if (imageUrl.startsWith("/")) return BASE_URL.replace(/\/$/, '') + imageUrl;
    return BASE_URL + imageUrl;
}

function isChapterImage(imageUrl) {
    if (!imageUrl) return false;
    return imageUrl.indexOf("/manga-images/") >= 0
        && /(jpg|jpeg|png|webp)(\?|$)/i.test(imageUrl);
}

function extractPageNumber(url) {
    // Pattern: /chapterDir/pageNum-timestamp-hash.jpg
    // Example: /0041/1-1773843324682-c34bfdb6.jpg
    let match = url.match(/\/(\d+)-\d+-[a-f0-9]+\.(jpg|jpeg|png|webp)/i);
    if (match) {
        return parseInt(match[1]);
    }
    
    // Fallback: /pageNum.jpg
    match = url.match(/\/(\d+)\.(jpg|jpeg|png|webp)$/i);
    if (match) {
        return parseInt(match[1]);
    }
    
    return 999999;
}

