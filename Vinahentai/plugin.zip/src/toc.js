load('config.js');

function execute(url, page) {
    let allChapters = [];
    let scanIndex = 0;
    
    // Fetch the manga detail page
    let response = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return null;
    }
    
    let doc = response.html();
    
    // Extract manga slug from current URL
    let mangaSlug = null;
    try {
        let urlParts = url.split('/');
        // Support both /truyen/{manga-slug} and /truyen-hentai/{manga-slug}
        if (urlParts.length >= 4 && (urlParts[1] === 'truyen' || urlParts[1] === 'truyen-hentai')) {
            mangaSlug = urlParts[3]; // /{truyen|truyen-hentai}/{manga-slug}/...
        }
    } catch (e) {
        // Continue without manga slug
    }
    
    // Method 1: Parse chapters from HTML - look for links with proper chapter URL structure
    // Links should be: /truyen-hentai/{manga-slug}/{chapter-slug} or /truyen/{manga-slug}/{chapter-slug}
    let allLinks = doc.select('a[href*="/truyen-hentai/"], a[href*="/truyen/"]');
    allLinks.forEach(link => {
        let href = link.attr('href');
        let linkText = cleanChapterTitle(link.text());
        
        if (!href || !linkText) return;
        
        // Filter out non-chapter links by text content
        let lowerText = linkText.toLowerCase();
        let badKeywords = [
            'bắt đầu đọc', 'bắt đầu', 'đọc ngay', 'đọc tiếp', 'tiếp tục',
            'đọc từ đầu', 'từ đầu', 'đọc mới nhất',
            'start reading', 'read now', 'continue', 'more info', 'details',
            'info', 'thông tin', 'xem thêm', 'chi tiết', 'update',
            'latest', 'mới nhất', 'genre', 'thể loại', 'author', 'tác giả',
            'artist', 'họa sĩ', 'status', 'trạng thái', 'rating', 'đánh giá',
            'xem trang', 'trang cá nhân', 'profile', 'manage', 'cài đặt'
        ];
        
        let isBadLink = false;
        for (let keyword of badKeywords) {
            if (lowerText.includes(keyword)) {
                isBadLink = true;
                break;
            }
        }
        if (isBadLink) return; // Skip navigation/info links
        
        try {
            let urlParts = href.split('/');
            let pathType = null;
            let mangaSlugIndex = -1;
            let chapterSlugIndex = -1;
            
            // Check for /truyen-hentai/{manga-slug}/{chapter-slug}
            if (urlParts[1] === 'truyen-hentai' && urlParts.length >= 4) {
                pathType = 'truyen-hentai';
                mangaSlugIndex = 2;
                chapterSlugIndex = 3;
            } 
            // Check for /truyen/{manga-slug}/{chapter-slug}
            else if (urlParts[1] === 'truyen' && urlParts.length >= 4) {
                pathType = 'truyen';
                mangaSlugIndex = 2;
                chapterSlugIndex = 3;
            }
            
            if (!pathType || chapterSlugIndex < 0) {
                return; // Skip - not a valid chapter URL
            }
            
            // Must have a chapter slug
            if (!urlParts[chapterSlugIndex] || urlParts[chapterSlugIndex] === '') {
                return; // Skip - no chapter slug
            }
            
            // If we know the manga slug, only include links for this manga
            if (mangaSlug && urlParts[mangaSlugIndex] !== mangaSlug) {
                return; // Skip - different manga
            }
            
            // Check for duplicates
            let isDuplicate = false;
            for (let i = 0; i < allChapters.length; i++) {
                if (allChapters[i].url === href) {
                    isDuplicate = true;
                    break;
                }
            }
            
            if (!isDuplicate) {
                allChapters.push({
                    name: linkText,
                    url: href,
                    host: BASE_URL,
                    _idx: scanIndex++
                });
            }
        } catch (e) {
            // Skip invalid URLs
        }
    });
    
    // Remove duplicates based on URL
    let uniqueChapters = [];
    let seenUrls = new Set();
    
    allChapters.forEach(chapter => {
        if (!seenUrls.has(chapter.url)) {
            seenUrls.add(chapter.url);
            uniqueChapters.push(chapter);
        }
    });
    
    // Sort chapters using robust keys from URL + title, fallback to source order.
    uniqueChapters.sort((a, b) => {
        let ka = extractSortKey(a);
        let kb = extractSortKey(b);

        // Main numeric chapters before non-numeric/special labels.
        if (ka.hasNum !== kb.hasNum) return ka.hasNum ? -1 : 1;

        // Numeric order when both have numbers.
        if (ka.hasNum && kb.hasNum && ka.num !== kb.num) {
            return ka.num - kb.num;
        }

        // Keep stable source order for ties/non-numeric chapters.
        return ka.idx - kb.idx;
    });

    // Clean internal fields.
    uniqueChapters.forEach(ch => {
        delete ch._idx;
    });
    
    return Response.success(uniqueChapters);
}

function extractChapterNumber(name) {
    if (!name) return null;
    
    // Normalize: remove extra spaces, convert to lowercase for matching
    let text = name.trim().replace(/\s+/g, ' ');
    
    // Pattern 1: "Chapter/Chap/Ch/Chương + number" (with optional dot)
    let patterns = [
        /\b(?:chapter|chap|ch|chương|chap.?|vol.*?ch)\s*\.?\s*(\d+(?:\.\d+)?)/i,
        /\b(?:tập|phần|tập|part|ep|episode)\s*\.?\s*(\d+(?:\.\d+)?)/i,
        /\b(\d+)\s*(?:\.|:|-|$)/,  // Standalone number at word boundary
        /^(\d+)(?:\.\d+)?$/,  // Simple number
        /(\d+(?:\.\d+)?)(?:\s|-|$)/  // Number followed by space, dash, or end
    ];
    
    for (let pattern of patterns) {
        let match = text.match(pattern);
        if (match && match[1]) {
            let num = parseFloat(match[1]);
            if (!isNaN(num)) {
                return num;
            }
        }
    }
    
    return null;
}

function cleanChapterTitle(text) {
    if (!text) return "";
    let t = ("" + text).replace(/\s+/g, ' ').trim();

    // Remove view counters in chapter labels (e.g. "1.2k views", "2.3K lượt xem", "view 123").
    t = t.replace(/\b\d+(?:[\.,]\d+)?\s*(?:k|m)?\s*(?:views?|lượt\s*xem|xem)\b/ig, ' ');
    t = t.replace(/\b(?:views?|lượt\s*xem|xem)\s*\d+(?:[\.,]\d+)?\s*(?:k|m)?\b/ig, ' ');

    // Trim separators left by removed tokens.
    t = t.replace(/[|•·]+/g, ' ');
    t = t.replace(/\s{2,}/g, ' ').trim();

    return t;
}

function extractSortKey(chapter) {
    let nameNum = extractChapterNumber(chapter.name);
    let urlNum = extractChapterNumber(extractChapterSlug(chapter.url));
    let num = urlNum !== null ? urlNum : nameNum;

    return {
        hasNum: num !== null,
        num: num !== null ? num : 999999,
        idx: typeof chapter._idx === 'number' ? chapter._idx : 999999
    };
}

function extractChapterSlug(url) {
    if (!url) return "";
    let p = ("" + url).split('?')[0].split('#')[0];
    let parts = p.split('/').filter(Boolean);
    return parts.length ? parts[parts.length - 1] : "";
}