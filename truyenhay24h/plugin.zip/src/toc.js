load('config.js');

function execute(url) {
    let slug = extractSlug(url);
    if (!slug) {
        slug = tryExtractSlugFromHtml(url);
    }

    if (!slug) {
        return Response.error("Khong lay duoc slug truyen");
    }

    let response = fetch(buildComicApiUrl(slug), {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });

    if (!response || !response.ok) {
        return Response.error("Khong tai duoc du lieu danh sach chuong");
    }

    let json = null;
    try {
        json = response.json();
    } catch (e) {
        return Response.error("Du lieu API khong hop le");
    }

    let payload = json && json.data ? json.data : null;
    let item = payload && payload.item ? payload.item : null;
    if (!item) {
        return Response.error("Khong tim thay item trong du lieu API");
    }

    let serverGroups = item.chapters || [];
    let chapters = [];
    let seen = {};

    serverGroups.forEach(function (group) {
        let arr = group && group.server_data ? group.server_data : [];
        arr.forEach(function (ch, idx) {
            let chapterNameRaw = cleanText(ch && ch.chapter_name ? ch.chapter_name : "");
            let chapterTitle = cleanText(ch && ch.chapter_title ? ch.chapter_title : "");
            let chapterApi = cleanText(ch && ch.chapter_api_data ? ch.chapter_api_data : "");

            let chapterNumber = extractChapterNumberFromText(chapterNameRaw);
            if (!chapterNumber) {
                chapterNumber = String(idx + 1);
            }

            let href = normalizeUrl("/truyen/" + slug + "/chapter-" + chapterNumber + "/");
            let key = chapterApi || href;
            if (!href || seen[key]) return;
            seen[key] = true;

            let label = chapterNameRaw ? ("Chapter " + chapterNameRaw) : ("Chapter " + chapterNumber);
            if (chapterTitle) {
                label += " - " + chapterTitle;
            }

            chapters.push({
                name: label,
                url: href,
                host: BASE_URL
            });
        });
    });

    chapters.sort(function (a, b) {
        let an = extractChapterNumber(a.url);
        let bn = extractChapterNumber(b.url);
        if (an !== bn) return an - bn;
        return a.url.localeCompare(b.url);
    });

    return Response.success(chapters);
}

function buildComicApiUrl(slug) {
    return "https://otruyenapi.com/v1/api/truyen-tranh/" + encodeURIComponent(slug);
}

function extractSlug(url) {
    let u = ("" + (url || "")).trim();
    if (!u) return "";

    let m = u.match(/\/v1\/api\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    return "";
}

function tryExtractSlugFromHtml(url) {
    if (!url) return "";

    try {
        let res = fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': BASE_URL
            }
        });
        if (!res || !res.ok) return "";

        let doc = res.html();
        let canonical = doc.select("link[rel='canonical']").attr("href") || "";
        let fromCanonical = extractSlug(canonical);
        if (fromCanonical) return fromCanonical;

        let ogUrl = doc.select("meta[property='og:url']").attr("content") || "";
        return extractSlug(ogUrl);
    } catch (e) {
        return "";
    }
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (e) {
        return text;
    }
}

function extractChapterNumberFromText(text) {
    let m = ("" + (text || "")).match(/(\d+(?:\.\d+)?)/);
    return m && m[1] ? m[1] : "";
}

function isChapterUrl(url) {
    return /\/truyen\/[^\/]+\/chapter-[^\/]+\/?$/i.test(url);
}

function extractChapterNumber(url) {
    let m = (url || "").match(/\/chapter-(\d+(?:\.\d+)?)\/?$/i);
    if (m && m[1]) return parseFloat(m[1]);
    return 999999;
}

function normalizeUrl(url) {
    if (!url) return "";
    url = ("" + url).trim();
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;

    let base = BASE_URL.replace(/\/$/, "");
    if (url.indexOf("/") === 0) return base + url;
    return base + "/" + url;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}
