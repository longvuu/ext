load('config.js');

function execute(url) {
    let chapterApiUrl = extractChapterApiUrl(url);

    if (!chapterApiUrl) {
        chapterApiUrl = resolveChapterApiUrlFromWebUrl(url);
    }

    if (!chapterApiUrl) {
        return Response.error("Khong lay duoc chapter_api_data");
    }

    let chapterRes = fetch(chapterApiUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });

    if (!chapterRes || !chapterRes.ok) {
        return Response.error("Khong tai duoc du lieu chapter API");
    }

    let json = null;
    try {
        json = chapterRes.json();
    } catch (e) {
        return Response.error("Du lieu chapter API khong hop le");
    }

    let data = json && json.data ? json.data : null;
    let item = data && data.item ? data.item : null;
    if (!item) {
        return Response.error("Khong tim thay item chapter");
    }

    let domain = cleanText(data && data.domain_cdn ? data.domain_cdn : "");
    let chapterPath = cleanText(item.chapter_path || "");
    let images = item.chapter_image || [];
    if (!images || !images.length) {
        return Response.error("Chapter khong co danh sach anh");
    }

    let pages = [];
    images.forEach(function (img, idx) {
        let file = cleanText(img && img.image_file ? img.image_file : "");
        if (!file) return;

        let order = toNumber(img && img.image_page, idx);
        let pageUrl = buildImageUrl(domain, chapterPath, file);
        if (!pageUrl) return;

        pages.push({
            order: order,
            url: pageUrl
        });
    });

    pages.sort(function (a, b) { return a.order - b.order; });

    let result = [];
    pages.forEach(function (p) {
        if (result.indexOf(p.url) < 0) result.push(p.url);
    });

    if (!result.length) {
        return Response.error("Khong tao duoc URL anh chapter");
    }

    return Response.success(result);
}

function resolveChapterApiUrlFromWebUrl(url) {
    let slug = extractSlug(url);
    let chapterName = extractChapterName(url);
    if (!slug || !chapterName) return "";

    let comicApi = "https://otruyenapi.com/v1/api/truyen-tranh/" + encodeURIComponent(slug);
    let comicRes = fetch(comicApi, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });
    if (!comicRes || !comicRes.ok) return "";

    let json = null;
    try {
        json = comicRes.json();
    } catch (e) {
        return "";
    }

    let item = json && json.data && json.data.item ? json.data.item : null;
    let groups = item && item.chapters ? item.chapters : [];
    let exactMatch = "";
    let looseMatch = "";

    groups.forEach(function (group) {
        let arr = group && group.server_data ? group.server_data : [];
        arr.forEach(function (ch) {
            let api = cleanText(ch && ch.chapter_api_data ? ch.chapter_api_data : "");
            if (!api) return;

            let name = cleanText(ch && ch.chapter_name ? ch.chapter_name : "");
            if (!name) return;

            if (name === chapterName && !exactMatch) {
                exactMatch = api;
                return;
            }

            if (!looseMatch) {
                let n1 = normalizeChapterNumber(name);
                let n2 = normalizeChapterNumber(chapterName);
                if (n1 && n2 && n1 === n2) {
                    looseMatch = api;
                }
            }
        });
    });

    return exactMatch || looseMatch;
}

function extractChapterApiUrl(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/https?:\/\/[^\s?#]+\/v1\/api\/chapter\/[^\s?#]+/i);
    return m && m[0] ? m[0] : "";
}

function extractSlug(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/truyen\/(.+?)\/chapter-/i);
    if (m && m[1]) return cleanText(m[1]);

    m = u.match(/\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(m[1]);

    m = u.match(/\/v1\/api\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(m[1]);

    return "";
}

function extractChapterName(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/chapter-([^\/?#]+)\/?/i);
    if (!m || !m[1]) return "";

    return decodeURIComponentSafe(cleanText(m[1]));
}

function normalizeChapterNumber(text) {
    let m = cleanText(text).match(/\d+(?:\.\d+)?/);
    return m && m[0] ? m[0] : "";
}

function buildImageUrl(domain, chapterPath, file) {
    let d = cleanText(domain || "").replace(/\/+$/, "");
    let p = cleanText(chapterPath || "").replace(/^\/+/, "").replace(/\/+$/, "");
    let f = cleanText(file || "").replace(/^\/+/, "");
    if (!p || !f) return "";

    if (d) return d + "/" + p + "/" + f;
    return "https://sv1.otruyencdn.com/" + p + "/" + f;
}

function toNumber(value, fallback) {
    let n = parseFloat(value);
    if (isNaN(n)) return fallback;
    return n;
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (e) {
        return text;
    }
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}
