load('config.js');

function execute(url) {
    let slug = extractSlug(url);
    if (!slug) {
        slug = tryExtractSlugFromHtml(url);
    }

    if (!slug) {
        return Response.error("Khong lay duoc slug truyen");
    }

    let response = fetch(buildComicApiUrl(slug), {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });

    if (!response || !response.ok) {
        return Response.error("Khong tai duoc du lieu chi tiet");
    }

    let json = null;
    try {
        json = response.json();
    } catch (e) {
        return Response.error("Du lieu API khong hop le");
    }

    let payload = json && json.data ? json.data : null;
    let item = payload && payload.item ? payload.item : null;
    let seo = payload && payload.seoOnPage ? payload.seoOnPage : null;

    if (!item) {
        return Response.error("Khong tim thay thong tin truyen");
    }

    let name = cleanText(item.name || "");
    if (!name) name = cleanText(slug.replace(/-/g, " "));

    let cdnDomain = (payload && payload.APP_DOMAIN_CDN_IMAGE) ? payload.APP_DOMAIN_CDN_IMAGE : "https://img.otruyenapi.com";
    let cover = buildCoverUrl(item.thumb_url, cdnDomain, seo);

    let author = "Dang cap nhat";
    if (item.author && item.author.forEach) {
        let arr = [];
        item.author.forEach(function (a) {
            let t = cleanText(a);
            if (t) arr.push(t);
        });
        if (arr.length > 0) author = arr.join(", ");
    }

    let description = "";
    if (item.content) {
        description = cleanText(stripHtml(item.content));
    }
    if (!description && seo && seo.descriptionHead) {
        description = cleanText(seo.descriptionHead);
    }

    let status = cleanText(item.status || "").toLowerCase();
    let ongoing = status !== "completed";

    let genres = [];
    let seen = {};
    if (item.category && item.category.forEach) {
        item.category.forEach(function (c) {
            let title = cleanText(c && c.name ? c.name : "");
            let slugCate = cleanText(c && c.slug ? c.slug : "");
            if (!title) return;

            let href = slugCate ? normalizeUrl("/the-loai/" + slugCate) : "";
            let key = href || title;
            if (seen[key]) return;
            seen[key] = true;

            genres.push({
                title: title,
                input: href,
                script: "source.js"
            });
        });
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        ongoing: ongoing,
        host: BASE_URL,
        genres: genres
    });
}

function buildComicApiUrl(slug) {
    return "https://otruyenapi.com/v1/api/truyen-tranh/" + encodeURIComponent(slug);
}

function buildCoverUrl(thumbUrl, cdnDomain, seo) {
    let cdn = (cdnDomain || "https://img.otruyenapi.com").replace(/\/$/, "");

    if (thumbUrl) {
        let thumb = ("" + thumbUrl).trim();
        if (thumb.indexOf("http") === 0) return thumb;
        thumb = thumb.replace(/^\/+/, "");
        return cdn + "/uploads/comics/" + thumb;
    }

    if (seo && seo.og_image && seo.og_image.length > 0) {
        let og = ("" + seo.og_image[0]).trim();
        if (og.indexOf("http") === 0) return og;
        og = og.replace(/^\/+/, "");
        return cdn + "/" + og;
    }

    return "";
}

function extractSlug(url) {
    let u = ("" + (url || "")).trim();
    if (!u) return "";

    let m = u.match(/\/v1\/api\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    return "";
}

function tryExtractSlugFromHtml(url) {
    if (!url) return "";

    try {
        let res = fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': BASE_URL
            }
        });
        if (!res || !res.ok) return "";

        let doc = res.html();
        let canonical = doc.select("link[rel='canonical']").attr("href") || "";
        let fromCanonical = extractSlug(canonical);
        if (fromCanonical) return fromCanonical;

        let ogUrl = doc.select("meta[property='og:url']").attr("content") || "";
        return extractSlug(ogUrl);
    } catch (e) {
        return "";
    }
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (e) {
        return text;
    }
}

function stripHtml(html) {
    if (!html) return "";
    return ("" + html).replace(/<[^>]*>/g, " ");
}

function normalizeUrl(url) {
    if (!url) return "";
    url = ("" + url).trim();
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;

    let base = BASE_URL.replace(/\/$/, "");
    if (url.indexOf("/") === 0) return base + url;
    return base + "/" + url;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}
