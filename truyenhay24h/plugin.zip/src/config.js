let BASE_URL = "https://truyenhay24h.net/";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}