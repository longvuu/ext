load('config.js');

function execute() {
    return Response.success([
        { title: "Truyện Mới", input: BASE_URL + "truyen-tranh", script: "source.js" },
    ]);
}