load('config.js');

function execute(url, page) {
    page = page ? String(page) : "1";
    let requestUrl = buildPagedUrl(url, page);
    let browser = null;

    let response = fetch(requestUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
            "Referer": BASE_URL
        }
    });

    if (!response || !response.ok) {
        return Response.error("Khong tai duoc danh sach truyen: " + requestUrl);
    }

    let books = [];
    let seen = {};

    let doc = response.html();
    collectFromCards(doc, books, seen);

    // Fallback: some pages return blocked/challenge content for plain fetch.
    if (books.length === 0) {
        try {
            browser = Engine.newBrowser();
            browser.setUserAgent(UserAgent.chrome());
            browser.launch(requestUrl, 12);
            browser.callJs("", 1500);
            let doc2 = browser.html();
            collectFromCards(doc2, books, seen);
            doc = doc2;
        } catch (ignoreBrowserError) {
            // Keep using fetch doc for fallback methods below.
        } finally {
            if (browser) {
                try { browser.close(); } catch (closeError) {}
                browser = null;
            }
        }
    }

    // Fallback: parse ItemList JSON-LD if HTML card selector changes.
    if (books.length === 0) {
        collectFromJsonLd(doc, books, seen);
    }

    // Last fallback: generic detail links.
    if (books.length === 0) {
        let links = doc.select("a[href*='/truyen/']");
        links.forEach(function (a) {
            let href = normalizeUrl(a.attr("href"));
            if (!isDetailUrl(href) || seen[href]) return;

            let name = cleanText(a.attr("title")) || cleanText(a.text());
            if (!name || name.length < 2) return;

            let cover = "";
            let img = a.select("img").first();
            if (img) {
                cover = img.attr("data-src") || img.attr("src") || "";
            }

            seen[href] = true;
            books.push({
                name: name,
                link: href,
                cover: normalizeUrl(cover),
                description: "",
                host: BASE_URL
            });
        });
    }

    let next = getNextPage(doc, page);
    return Response.success(books, next);
}

function collectFromCards(doc, books, seen) {
    if (!doc) return;

    let cards = doc.select(".otr-home-grid .otr-home-card, .otr-home-card");
    cards.forEach(function (card) {
        let linkNode = card.select("a.otr-home-thumb, h3.otr-home-name a, a[href*='/truyen/']").first();
        if (!linkNode) return;

        let href = normalizeUrl(linkNode.attr("href"));
        if (!isDetailUrl(href) || seen[href]) return;

        let name = cleanText(card.select("h3.otr-home-name a").text());
        if (!name) name = cleanText(linkNode.attr("title"));
        if (!name) name = cleanText(linkNode.text());
        if (!name) return;

        let cover = "";
        let img = card.select("a.otr-home-thumb img, img").first();
        if (img) {
            cover = img.attr("data-src") || img.attr("data-lazy-src") || img.attr("src") || "";
        }

        let cats = cleanText(card.select(".otr-home-cats").text());
        let meta = cleanText(card.select(".otr-home-meta").text());
        let desc = cleanText((cats ? cats + " | " : "") + meta);

        seen[href] = true;
        books.push({
            name: name,
            link: href,
            cover: normalizeUrl(cover),
            description: desc,
            host: BASE_URL
        });
    });
}

function buildPagedUrl(url, page) {
    let p = parseInt(page || "1", 10);
    if (!p || p < 1) p = 1;

    // Site pagination uses otr_page in index.html.
    if (/[?&]otr_page=/i.test(url)) {
        return url.replace(/([?&]otr_page=)\d+/i, "$1" + p);
    }

    // Keep compatibility if input already uses page param.
    if (/[?&]page=/i.test(url)) {
        return url.replace(/([?&]page=)\d+/i, "$1" + p);
    }

    if (url.indexOf("?") >= 0) {
        return url + "&otr_page=" + p;
    }

    return url + "?otr_page=" + p;
}

function collectFromJsonLd(doc, books, seen) {
    if (!doc) return;

    let scripts = doc.select("script[type='application/ld+json']");
    scripts.forEach(function (sc) {
        let raw = sc.html() || sc.text() || "";
        if (!raw || raw.indexOf("ItemList") < 0) return;

        try {
            let json = JSON.parse(raw);
            if (!json) return;

            // ItemList object
            if (json.itemListElement && json.itemListElement.forEach) {
                json.itemListElement.forEach(function (it) {
                    addJsonBook(it, books, seen);
                });
            }

            // Graph array case
            if (json['@graph'] && json['@graph'].forEach) {
                json['@graph'].forEach(function (node) {
                    if (node && node.itemListElement && node.itemListElement.forEach) {
                        node.itemListElement.forEach(function (it) {
                            addJsonBook(it, books, seen);
                        });
                    }
                });
            }
        } catch (ignoreJson) {
            // Ignore malformed json-ld blocks.
        }
    });
}

function addJsonBook(it, books, seen) {
    if (!it) return;

    let href = normalizeUrl(it.url || (it.item && it.item['@id']) || "");
    if (!isDetailUrl(href) || seen[href]) return;

    let name = cleanText(it.name || (it.item && it.item.name) || "");
    if (!name) return;

    let cover = normalizeUrl(it.image || (it.item && it.item.image) || "");
    seen[href] = true;
    books.push({
        name: name,
        link: href,
        cover: cover,
        description: "",
        host: BASE_URL
    });
}

function getNextPage(doc, page) {
    let p = parseInt(page || "1", 10);
    if (!p || p < 1) p = 1;

    let nextBtn = doc.select(".otr-home-pagination a.next-page, .otr-home-pagination a.otr-home-page-btn.next-page").first();
    if (nextBtn) {
        let href = nextBtn.attr("href") || "";
        let m = href.match(/[?&](?:otr_page|page)=(\d+)/i);
        if (m && m[1]) return String(parseInt(m[1], 10));
        return String(p + 1);
    }

    let numbered = doc.select(".otr-home-pagination a.otr-home-page-num, .pagination a.page-number");
    if (numbered && numbered.size() > 0) {
        for (let i = 0; i < numbered.size(); i++) {
            let t = cleanText(numbered.get(i).text());
            if (/^\d+$/.test(t)) {
                let pn = parseInt(t, 10);
                if (pn > p) return String(pn);
            }
        }
    }

    return "";
}

function isDetailUrl(url) {
    if (!url) return false;
    return /\/truyen\/[^\/]+\/?$/i.test(url);
}

function normalizeUrl(url) {
    if (!url) return "";
    url = ("" + url).trim();
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;

    let base = BASE_URL.replace(/\/$/, "");
    if (url.indexOf("/") === 0) return base + url;
    return base + "/" + url;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}
