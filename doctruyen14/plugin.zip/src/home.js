function execute() {
    return Response.success([
        {title: "Truyện Ma", input: "https://doctruyen14.vip/truyen-ma/", script:"source.js"},
        {title: "Truyện Teen", input: "https://doctruyen14.vip/truyen-teen/", script:"source.js"},
        {title: "Truyện Tình Cảm", input: "https://doctruyen14.vip/truyen-tinh-cam/", script:"source.js"},
        {title: "Truyện Sex", input: "https://doctruyen14.vip/truyen-sex-nguoi-lon/", script:"source.js"},
        {title: "Truyện Cười", input: "https://doctruyen14.vip/truyen-cuoi/", script:"source.js"},
        {title: "Truyện Gay", input: "https://doctruyen14.vip/truyen-gay/", script:"source.js"},
        {title: "Truyện Les", input: "https://doctruyen14.vip/truyen-les/", script:"source.js"}
    ]);
}