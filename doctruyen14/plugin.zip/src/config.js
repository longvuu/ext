let BASE_URL = "https://doctruyen14.vip/";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}