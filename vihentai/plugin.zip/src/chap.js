load('config.js');

function execute(url) {
    var browser = null;

    try {
        let imgs = [];
        let response = fetch(url);
        if (response && response.ok) {
            let doc = response.html();
            let raw = getRawText(response, doc);
            collectFromDoc(doc, imgs);
            collectFromRaw(raw, imgs);
        }

        if (imgs.length === 0) {
            browser = Engine.newBrowser();
            browser.setUserAgent(UserAgent.android());
            browser.launch(url, 8);

            // Cho trang có thời gian chạy JavaScript (read.js render chapter-content)
            browser.callJs("", 10000);

            // Inject: thu thap anh trong DOM va script
            browser.callJs(
                "(function(){"
                + "try {"
                + "  var found = [];"
                + "  function add(u){"
                + "    if(!u) return;"
                + "    u = String(u).replace(/\\u002F/gi,'/').replace(/\\\//g,'/').trim();"
                + "    if(found.indexOf(u) < 0) found.push(u);"
                + "  }"
                + "  var root = document.getElementById('chapter-content') || document.body;"
                + "  if(root){"
                + "    var imgs = root.querySelectorAll('img');"
                + "    for(var i=0;i<imgs.length;i++){"
                + "      add(imgs[i].getAttribute('src'));"
                + "      add(imgs[i].getAttribute('data-src'));"
                + "      add(imgs[i].getAttribute('data-lazy-src'));"
                + "      add(imgs[i].getAttribute('data-original'));"
                + "      var ss = imgs[i].getAttribute('srcset') || imgs[i].getAttribute('data-srcset') || '';"
                + "      if(ss){ add(ss.split(',')[0].trim().split(' ')[0]); }"
                + "    }"
                + "    var nodes = root.querySelectorAll(\"[style*='background-image']\");"
                + "    for(var j=0;j<nodes.length;j++){"
                + "      var st = nodes[j].getAttribute('style') || '';"
                + "      var m = st.match(/url\\(([^)]+)\\)/i);"
                + "      if(m && m[1]) add(m[1].replace(/['\"]+/g,''));"
                + "    }"
                + "  }"
                + "  var scripts = document.querySelectorAll('script');"
                + "  var all = '';"
                + "  for(var k=0;k<scripts.length;k++){ all += '\\n' + (scripts[k].textContent || ''); }"
                + "  var norm = all.replace(/\\u002F/gi,'/').replace(/\\\//g,'/');"
                + "  var m2 = norm.match(/https?:\\/\\/[^\"'\\s,]+\\.(jpg|jpeg|png|webp)(\\?[^\"'\\s,]*)?/gi) || [];"
                + "  for(var x=0;x<m2.length;x++){ add(m2[x]); }"
                + "  var holder = document.getElementById('__vh_chapter_urls');"
                + "  if(!holder){"
                + "    holder = document.createElement('script');"
                + "    holder.id = '__vh_chapter_urls';"
                + "    holder.type = 'application/json';"
                + "    document.body.appendChild(holder);"
                + "  }"
                + "  holder.textContent = JSON.stringify(found);"
                + "} catch(e) {}"
                + "})();",
                1200
            );

            let doc2 = browser.html();
            collectFromDoc(doc2, imgs);
            collectFromRaw(doc2.html() || "", imgs);

            try {
                let loadedUrls = browser.urls();
                if (loadedUrls && loadedUrls.forEach) {
                    loadedUrls.forEach(u => collectImageCandidate(u, imgs));
                }
            } catch (ignoreUrls) {}

            try {
                let payload = doc2.select("#__vh_chapter_urls").text();
                if (payload) {
                    let arr = JSON.parse(payload);
                    if (arr && arr.forEach) {
                        arr.forEach(u => collectImageCandidate(u, imgs));
                    }
                }
            } catch (ignorePayload) {}
        }

        if (browser) {
            try { browser.close(); } catch (closeError) {}
            browser = null;
        }

        if (imgs.length > 1) {
            imgs.sort((a, b) => extractImageNumber(a) - extractImageNumber(b));
        }

        if (imgs.length > 0) {
            return Response.success(imgs);
        }

        return Response.error("Khong tim thay anh tai: " + url);
    } catch (e) {
        if (browser) {
            try { browser.close(); } catch (closeError) {}
        }
        return Response.error("Loi: " + e.message);
    }
}

function getRawText(response, doc) {
    let raw = "";

    if (response) {
        if (response.text) {
            try { raw = response.text() || ""; } catch (ignore1) {}
        }
        if ((!raw || raw.length < 50) && response.body) {
            try { raw = response.body() || ""; } catch (ignore2) {}
        }
        if ((!raw || raw.length < 50) && response.string) {
            try { raw = response.string() || ""; } catch (ignore3) {}
        }
        if ((!raw || raw.length < 50) && response.toString) {
            try { raw = String(response.toString() || ""); } catch (ignore4) {}
        }
    }

    if ((!raw || raw.length < 50) && doc) {
        try { raw = doc.html() || ""; } catch (ignore5) {}
    }

    if ((!raw || raw.length < 50) && doc) {
        try {
            let scripts = [];
            doc.select("script").forEach(sc => {
                scripts.push(sc.html() || "");
                scripts.push(sc.text() || "");
            });
            raw = scripts.join("\n");
        } catch (ignore6) {}
    }

    return raw || "";
}

function collectFromDoc(doc, imgs) {
    if (!doc) return;

    let roots = [];
    let chapter = doc.select("#chapter-content");
    if (chapter && chapter.size && chapter.size() > 0) {
        roots.push(chapter);
    }
    let fallback = doc.select("div.text-center");
    if (fallback && fallback.size && fallback.size() > 0) {
        roots.push(fallback);
    }
    if (roots.length === 0) {
        roots.push(doc);
    }

    roots.forEach(root => {
        collectImagesFromElement(root, imgs);
    });
}

function collectImagesFromElement(root, imgs) {
    if (!root) return;

    let imgElements = root.select("img");
    imgElements.forEach(img => {
        collectImageCandidate(img.attr("src"), imgs);
        collectImageCandidate(img.attr("data-src"), imgs);
        collectImageCandidate(img.attr("data-lazy-src"), imgs);
        collectImageCandidate(img.attr("data-original"), imgs);
        collectImageCandidate(firstSrcFromSrcset(img.attr("srcset")), imgs);
        collectImageCandidate(firstSrcFromSrcset(img.attr("data-srcset")), imgs);
    });

    let withStyle = root.select("[style*='background-image']");
    withStyle.forEach(node => {
        let style = node.attr("style") || "";
        let match = style.match(/url\(([^)]+)\)/i);
        if (match && match[1]) {
            collectImageCandidate(match[1].replace(/['\"]+/g, ""), imgs);
        }
    });
}

function collectFromRaw(raw, imgs) {
    if (!raw) return;

    let normalized = raw.replace(/\\u002F/gi, "/").replace(/\\\//g, "/");

    let matches = normalized.match(/https?:\/\/[^"'\s<>]+\/(images\/data|storage\/images\/data|storage\/chapters|storage\/chapter|uploads\/chapters|manga-images)\/[^"'\s<>]+\.(jpg|jpeg|png|webp)(\?[^"'\s<>]*)?/gi);
    if (matches && matches.length > 0) {
        matches.forEach(u => collectImageCandidate(u, imgs));
    }

    let looseMatches = normalized.match(/https?:\/\/[^"'\s<>]+\.(jpg|jpeg|png|webp)(\?[^"'\s<>]*)?/gi);
    if (looseMatches && looseMatches.length > 0) {
        looseMatches.forEach(u => collectImageCandidate(u, imgs));
    }
}

function firstSrcFromSrcset(srcset) {
    if (!srcset) return "";
    let first = srcset.split(",")[0] || "";
    first = first.trim();
    if (!first) return "";
    return first.split(" ")[0].trim();
}

function collectImageCandidate(rawUrl, imgs) {
    let imageUrl = normalizeImageUrl(rawUrl);
    if (isChapterImage(imageUrl) && !imgs.includes(imageUrl)) {
        imgs.push(imageUrl);
    }
}

function normalizeImageUrl(imageUrl) {
    if (!imageUrl) return "";
    imageUrl = ("" + imageUrl).trim();
    imageUrl = imageUrl.replace(/\\u002F/gi, "/").replace(/\\\//g, "/");
    imageUrl = imageUrl.replace(/^['\"]+|['\"]+$/g, "");

    // Ensure full URL for images
    if (imageUrl.startsWith("//")) {
        return "https:" + imageUrl;
    } else if (imageUrl.startsWith("/")) {
        // Check if it's a relative path to S3 or to the main domain
        if (imageUrl.includes("@public")) {
            return "https://s3.lxmanga.xyz" + imageUrl;
        } else {
            return BASE_URL.replace(/\/$/, '') + imageUrl;
        }
    } else if (!imageUrl.startsWith("http")) {
        // If it's a relative path without leading slash
        return BASE_URL + imageUrl;
    }
    return imageUrl;
}

function isChapterImage(imageUrl) {
    if (!imageUrl) return false;
    if (!/(jpg|jpeg|png|webp)(\?|$)/i.test(imageUrl)) return false;

    let lowered = imageUrl.toLowerCase();
    if (lowered.indexOf("/images/cover/") >= 0) return false;
    if (lowered.indexOf("fav2.png") >= 0) return false;
    if (lowered.indexOf("loading.gif") >= 0) return false;
    if (lowered.indexOf("/imgs/") >= 0 && lowered.indexOf("/images/") < 0 && lowered.indexOf("/storage/") < 0) return false;

    return lowered.indexOf("/images/data/") >= 0
        || lowered.indexOf("/storage/images/data/") >= 0
        || lowered.indexOf("/storage/chapters/") >= 0
        || lowered.indexOf("/storage/chapter/") >= 0
        || lowered.indexOf("/uploads/chapters/") >= 0
        || lowered.indexOf("/manga-images/") >= 0;
}

function extractImageNumber(url) {
    // Extract number from URL for sorting (e.g., /0.png -> 0, /15.png -> 15)
    let match = url.match(/\/(\d+)\.(?:jpg|jpeg|png|gif|webp)/i);
    return match ? parseInt(match[1]) : 999999;
}