load('config.js');

function execute(url) {
    var browser = null;
    
    try {
        // Khởi tạo browser và load trang
        browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.android());
        
        // Launch trang với timeout 30 giây
        browser.launch(url, 30);
        
        // Cho trang có thời gian chạy JavaScript (10 giây)
        browser.callJs("", 10000);
        
        // Lấy HTML sau khi JavaScript đã render
        let doc = browser.html();
        var imgs = [];
        
        // Khu vực đọc truyện chính: div.text-center (index2.html) hoặc toàn bộ img (index.html)
        let imgElements = []; 
        let contentDiv = doc.select("div.text-center");
        if (contentDiv && contentDiv.size && contentDiv.size() > 0) {
            imgElements = contentDiv.select("img");
        } else {
            imgElements = doc.select("img");
        }

        // Tìm tất cả img tags và lấy src
        imgElements.forEach(img => {
            let imageUrl = img.attr("src");
            
            // Nếu không có src, thử data-src
            if (!imageUrl || imageUrl.trim() === "") {
                imageUrl = img.attr("data-src");
            }
            
            // Kiểm tra xem URL có phải ảnh hợp lệ không
            if (imageUrl && imageUrl.trim() !== "") {
                 // Chỉ lấy ảnh đọc truyện (ảnh trong thư mục images/data hoặc tương tự),
                 // loại bỏ ảnh bìa/covers và logo site
                 if ((imageUrl.indexOf("img.shousetsu.dev/images/data") >= 0 || 
                     imageUrl.indexOf("s3.lxmanga.xyz") >= 0) &&
                    imageUrl.indexOf("/covers/") < 0 &&
                    imageUrl.indexOf("/images/cover/") < 0 &&
                    imageUrl.indexOf("fav2.png") < 0) {
                    
                    imageUrl = normalizeImageUrl(imageUrl);
                    
                    if (!imgs.includes(imageUrl)) {
                        imgs.push(imageUrl);
                    }
                }
            }
        });
        
        // Sắp xếp ảnh theo số thứ tự
        if (imgs.length > 1) {
            imgs.sort((a, b) => {
                let aNum = extractImageNumber(a);
                let bNum = extractImageNumber(b);
                return aNum - bNum;
            });
        }
        
        // Đóng browser
        browser.close();
        
        // Trả về kết quả
        if (imgs.length > 0) {
            return Response.success(imgs);
        } else {
            return Response.error("Không tìm thấy ảnh tại: " + url);
        }
        
    } catch (e) {
        // Đảm bảo đóng browser nếu có lỗi
        if (browser) {
            try {
                browser.close();
            } catch (closeError) {
                // Ignore
            }
        }
        return Response.error("Lỗi: " + e.message);
    }
}

function normalizeImageUrl(imageUrl) {
    // Ensure full URL for images
    if (imageUrl.startsWith("//")) {
        return "https:" + imageUrl;
    } else if (imageUrl.startsWith("/")) {
        // Check if it's a relative path to S3 or to the main domain
        if (imageUrl.includes("@public")) {
            return "https://s3.lxmanga.xyz" + imageUrl;
        } else {
            return BASE_URL.replace(/\/$/, '') + imageUrl;
        }
    } else if (!imageUrl.startsWith("http")) {
        // If it's a relative path without leading slash
        return BASE_URL + imageUrl;
    }
    return imageUrl;
}

function extractImageNumber(url) {
    // Extract number from URL for sorting (e.g., /0.png -> 0, /15.png -> 15)
    let match = url.match(/\/(\d+)\.(?:jpg|jpeg|png|gif|webp)/i);
    return match ? parseInt(match[1]) : 999999;
}