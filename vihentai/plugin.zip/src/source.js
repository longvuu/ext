load("config.js");

function execute(url, page) {
    if (!page) page = '1';
    
    // Ensure proper URL format
    let requestUrl = url;
    if (url.indexOf('?') > -1) {
        // URL already has parameters, append page parameter
        requestUrl = url + "&page=" + page;
    } else {
        // URL doesn't have parameters, add page parameter
        requestUrl = url + "?page=" + page;
    }
    
    let response = fetch(requestUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return Response.error("Không thể tải trang web: " + requestUrl);
    }
    
    let doc = response.html();
    let nextPage = "";
    
    // Debug: log the request URL
    console.log("Request URL: " + requestUrl);
    console.log("BASE_URL: " + BASE_URL);
    
    // Check for next page - look for pagination links
    let currentPageNum = parseInt(page);
    let paginationLinks = doc.select("a:contains(" + (currentPageNum + 1) + ")");
    if (paginationLinks.size() > 0) {
        nextPage = (currentPageNum + 1).toString();
    }

    let books = [];
    
    // Parse manga items from the grid
    let mangaContainers = doc.select(".manga-vertical");
    
    mangaContainers.forEach(mangaVertical => {
        try {
            // Find the main manga link in the title area
            let titleLink = mangaVertical.select("a.text-ellipsis").first();
            if (!titleLink) return;
            
            let href = titleLink.attr("href");
            let name = titleLink.text().trim();
            
            // Skip if name is empty or invalid
            if (!name || name.length < 2) return;
            
            // Ensure absolute URL for manga link
            if (href && !href.startsWith("http")) {
                let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                href = baseUrl + (href.startsWith("/") ? href : "/" + href);
            }
            
            // Get cover image from background-image style
            let cover = "";
            let coverElement = mangaVertical.select(".cover").first();
            if (coverElement) {
                let style = coverElement.attr("style");
                if (style) {
                    // Extract URL from background-image: url('...')
                    let match = style.match(/url\(['"](.*?)['"]\)/);
                    if (!match) {
                        // Try without quotes
                        match = style.match(/url\((.*?)\)/);
                    }
                    if (match && match[1]) {
                        cover = match[1].trim();
                    }
                }
            }
            
            // Ensure cover is absolute URL
            if (cover && !cover.startsWith("http")) {
                let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                cover = baseUrl + (cover.startsWith("/") ? cover : "/" + cover);
            }
            
            // Check if we already have this manga (avoid duplicates)
            let alreadyExists = false;
            for (let i = 0; i < books.length; i++) {
                if (books[i].name === name || books[i].link === href) {
                    alreadyExists = true;
                    break;
                }
            }
            
            if (!alreadyExists && href && name) {
                books.push({
                    name: name,
                    link: href,
                    cover: cover,
                    description: "",
                    host: BASE_URL,
                    author: ""
                });
            }
        } catch (e) {
            // Skip invalid items
        }
    });

    return Response.success(books, nextPage);
}
