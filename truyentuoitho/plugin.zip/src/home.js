load('config.js');

function execute() {
    return Response.success([
        { title: "Truyện Mới", input: BASE_URL + "manga/?m_orderby=new-manga", script: "source.js" },
    ]);
}