load('config.js');

function execute(url) {
    let inputUrl = cleanText(url);
    if (!inputUrl) return Response.error("URL khong hop le");

    let directApi = extractChapterApiUrl(inputUrl);
    if (directApi) {
        let pagesFromApi = loadImagesFromOtruyenApi(directApi);
        if (pagesFromApi && pagesFromApi.length) return Response.success(pagesFromApi);
        return Response.error("Khong tai duoc du lieu chapter API");
    }
 
    let chapterUrl = resolveRealChapterUrl(inputUrl);
    if (!chapterUrl) chapterUrl = inputUrl;

    let chapterDoc = loadHtmlDocument(chapterUrl, inputUrl);
    if (chapterDoc) {
        let images = extractImagesFromChapterDoc(chapterDoc, chapterUrl);
        if (images.length) {
            return Response.success(images);
        }

        let iframePages = extractPagesFromDriveIframe(chapterDoc, chapterUrl);
        if (iframePages.length) {
            return Response.success(iframePages);
        }
    }

    let fallbackApi = resolveChapterApiUrlFromWebUrl(chapterUrl || inputUrl);
    if (fallbackApi) {
        let pages = loadImagesFromOtruyenApi(fallbackApi);
        if (pages && pages.length) return Response.success(pages);
    }

    return Response.error("Khong lay duoc noi dung chapter");
}

function resolveRealChapterUrl(url) {
    let u = cleanText(url);
    if (!u) return "";

    if (/\/manga\/[^\/]+\/(?:tap|chuong|chapter)-/i.test(u)) {
        return u;
    }

    let slug = extractSlug(u);
    let chapterName = extractChapterNameFromUrl(u);
    if (!slug || !chapterName) return u;

    let endpoint = normalizeUrl("/manga/" + slug + "/ajax/chapters/?t=1");
    let doc = loadAjaxChapterList(endpoint, normalizeUrl("/manga/" + slug + "/"));
    if (!doc) return u;

    let best = "";
    let links = doc.select("li.wp-manga-chapter a[href], .listing-chapters_wrap a[href]");
    links.forEach(function (a) {
        if (best) return;
        let href = normalizeUrl(a.attr("href") || "");
        if (!href) return;

        let fromHref = extractChapterNameFromUrl(href);
        let fromText = extractChapterNameFromText(a.text());
        let fromTitle = extractChapterNameFromText(a.attr("title") || "");

        if (chapterName && fromHref && chapterName === fromHref) {
            best = href;
            return;
        }

        if (chapterName && fromText && chapterName === fromText) {
            best = href;
            return;
        }

        if (chapterName && fromTitle && chapterName === fromTitle) {
            best = href;
            return;
        }
    });

    return best || u;
}

function loadAjaxChapterList(endpoint, refererUrl) {
    try {
        let response = fetch(endpoint, {
            method: "POST",
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': refererUrl || BASE_URL,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        if (response && response.ok) return response.html();
    } catch (e) {
    }

    try {
        let fallback = fetch(endpoint, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': refererUrl || BASE_URL,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        if (fallback && fallback.ok) return fallback.html();
    } catch (e) {
    }

    return null;
}

function loadHtmlDocument(url, refererUrl) {
    let headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Referer': refererUrl || BASE_URL
    };

    try {
        let response = fetch(url, { headers: headers });
        if (response && response.ok) return response.html();
    } catch (e) {
    }

    try {
        let browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.chrome());
        browser.launch(url, 15);
        browser.callJs("", 1200);
        let doc = browser.html();
        try { browser.close(); } catch (closeError) {}
        return doc;
    } catch (e) {
    }

    return null;
}

function extractImagesFromChapterDoc(doc, refererUrl) {
    let selectors = [
        ".reading-content .page-box img",
        ".reading-content #comic-wrap img",
        ".reading-content > .text-left img",
        ".reading-content img",
        "#comic-wrap img",
        ".page-box img"
    ];

    let urls = [];
    let seen = {};
    selectors.forEach(function (sel) {
        let els = doc.select(sel);
        els.forEach(function (img) {
            let src = cleanText(
                img.attr("data-src") ||
                img.attr("data-original") ||
                img.attr("data-lazy-src") ||
                img.attr("data-lazy") ||
                img.attr("src") || ""
            );
            if (!src) return;

            src = normalizeUrlByReferer(src, refererUrl);
            if (!isLikelyImageUrl(src)) return;
            if (isNoiseImage(src)) return;
            if (seen[src]) return;

            seen[src] = true;
            urls.push(src);
        });
    });

    return urls;
}

function extractPagesFromDriveIframe(doc, refererUrl) {
    let frame = doc.select(".reading-content iframe[src], .read-container iframe[src]");
    let src = normalizeUrlByReferer(cleanText(frame.attr("src") || ""), refererUrl || BASE_URL);
    if (!src) return [];
    let pages = extractPagesFromDriveViewer(src, refererUrl || BASE_URL);
    if (pages.length) return pages;

    let fallback = [];
    let fileId = extractDriveFileId(src);
    if (fileId) {
        fallback.push("https://drive.usercontent.google.com/uc?id=" + fileId + "&export=download");
        fallback.push("https://drive.google.com/uc?export=download&id=" + fileId);
    }
    return fallback;
}

function extractPagesFromDriveViewer(previewUrl, refererUrl) {
    if (!/drive\.google\.com/i.test(previewUrl)) return [];

    let headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Referer': refererUrl || BASE_URL
    };

    let previewHtml = fetchTextSafe(previewUrl, headers);
    if (!previewHtml) return [];

    let uploadUrl = extractDriveUploadUrl(previewHtml);
    if (!uploadUrl) return [];

    let uploadText = fetchTextSafe(uploadUrl, headers);
    let uploadJson = parseDriveViewerJson(uploadText);
    if (!uploadJson) return [];

    let imagePath = cleanText(uploadJson.img || uploadJson.page || "");
    if (!imagePath) return [];

    let imageBase = buildDriveViewerUrl(imagePath);
    if (!imageBase) return [];

    let totalPages = 0;
    let metaPath = cleanText(uploadJson.meta || "");
    if (metaPath) {
        let metaText = fetchTextSafe(buildDriveViewerUrl(metaPath), headers);
        let metaJson = parseDriveViewerJson(metaText);
        totalPages = toNumber(metaJson && metaJson.pages, 0);
    }

    let pages = [];
    if (totalPages > 0) {
        let max = Math.min(totalPages, 1200);
        for (let i = 1; i <= max; i++) {
            pages.push(imageBase + "&page=" + i + "&w=2000");
        }
    } else {
        pages.push(imageBase + "&page=1&w=2000");
    }

    let seen = {};
    return pages.filter(function (u) {
        if (!u) return false;
        if (seen[u]) return false;
        seen[u] = true;
        return true;
    });
}

function extractDriveUploadUrl(previewHtml) {
    let html = cleanTextRaw(previewHtml);
    if (!html) return "";

    let uploadEscapedRe = new RegExp("https:\\\\/\\\\/drive\\.google\\.com\\\\/viewer\\\\/upload\\?ds[^\"'\\s<>]+", "i");
    let m = html.match(uploadEscapedRe);
    if (!m || !m[0]) {
        let uploadPlainRe = new RegExp("https:\\/\\/drive\\.google\\.com\\/viewer\\/upload\\?ds[^\"'\\s<>]+", "i");
        m = html.match(uploadPlainRe);
    }
    if (!m || !m[0]) return "";

    let u = decodeDriveEscapedUrl(m[0]);
    if (!u) return "";

    return normalizeUrlByReferer(u, "https://drive.google.com/");
}

function parseDriveViewerJson(text) {
    let t = cleanTextRaw(text);
    if (!t) return null;

    t = t.replace(/^\)\]\}'\s*/, "");
    try {
        return JSON.parse(t);
    } catch (e) {
        return null;
    }
}

function buildDriveViewerUrl(pathOrUrl) {
    let p = cleanText(pathOrUrl);
    if (!p) return "";
    if (/^https?:\/\//i.test(p)) return p;
    return "https://drive.google.com/viewer/" + p.replace(/^\/+/, "");
}

function decodeDriveEscapedUrl(url) {
    let u = cleanTextRaw(url);
    if (!u) return "";

    return u
        .replace(/\\u003d/gi, "=")
        .replace(/\\u0026/gi, "&")
        .replace(/\\u002f/gi, "/")
        .replace(/\\\//g, "/")
        .replace(/&amp;/gi, "&")
        .trim();
}

function fetchTextSafe(url, headers) {
    let u = cleanText(url);
    if (!u) return "";

    try {
        let res = fetch(u, { headers: headers || {} });
        if (res && res.ok) return res.text() || "";
    } catch (e) {
    }

    return "";
}

function extractDriveFileId(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/file\/d\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(m[1]);

    m = u.match(/[?&]id=([^&#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    return "";
}

function loadImagesFromOtruyenApi(chapterApiUrl) {
    let chapterRes = fetch(chapterApiUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });

    if (!chapterRes || !chapterRes.ok) {
        return [];
    }

    let json = null;
    try {
        json = chapterRes.json();
    } catch (e) {
        return [];
    }

    let data = json && json.data ? json.data : null;
    let item = data && data.item ? data.item : null;
    if (!item) {
        return [];
    }

    let domain = cleanText(data && data.domain_cdn ? data.domain_cdn : "");
    let chapterPath = cleanText(item.chapter_path || "");
    let images = item.chapter_image || [];
    if (!images || !images.length) {
        return [];
    }

    let pages = [];
    images.forEach(function (img, idx) {
        let file = cleanText(img && img.image_file ? img.image_file : "");
        if (!file) return;

        let order = toNumber(img && img.image_page, idx);
        let pageUrl = buildImageUrl(domain, chapterPath, file);
        if (!pageUrl) return;

        pages.push({
            order: order,
            url: pageUrl
        });
    });

    pages.sort(function (a, b) { return a.order - b.order; });

    let result = [];
    pages.forEach(function (p) {
        if (result.indexOf(p.url) < 0) result.push(p.url);
    });

    return result;
}

function resolveChapterApiUrlFromWebUrl(url) {
    let slug = extractSlug(url);
    let chapterName = extractChapterNameFromUrl(url);
    if (!slug || !chapterName) return "";

    let comicApi = "https://otruyenapi.com/v1/api/truyen-tranh/" + encodeURIComponent(slug);
    let comicRes = fetch(comicApi, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            'Referer': BASE_URL
        }
    });
    if (!comicRes || !comicRes.ok) return "";

    let json = null;
    try {
        json = comicRes.json();
    } catch (e) {
        return "";
    }

    let item = json && json.data && json.data.item ? json.data.item : null;
    let groups = item && item.chapters ? item.chapters : [];
    let exactMatch = "";
    let looseMatch = "";

    groups.forEach(function (group) {
        let arr = group && group.server_data ? group.server_data : [];
        arr.forEach(function (ch) {
            let api = cleanText(ch && ch.chapter_api_data ? ch.chapter_api_data : "");
            if (!api) return;

            let name = cleanText(ch && ch.chapter_name ? ch.chapter_name : "");
            if (!name) return;

            if (name === chapterName && !exactMatch) {
                exactMatch = api;
                return;
            }

            if (!looseMatch) {
                let n1 = normalizeChapterNumber(name);
                let n2 = normalizeChapterNumber(chapterName);
                if (n1 && n2 && n1 === n2) {
                    looseMatch = api;
                }
            }
        });
    });

    return exactMatch || looseMatch;
}

function extractChapterApiUrl(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/https?:\/\/[^\s?#]+\/v1\/api\/chapter\/[^\s?#]+/i);
    return m && m[0] ? m[0] : "";
}

function extractSlug(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/manga\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(m[1]);

    m = u.match(/\/v1\/api\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(m[1]);

    return "";
}

function extractChapterNameFromUrl(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/chapter-([^\/?#]+)\/?/i);
    if (m && m[1]) return decodeURIComponentSafe(cleanText(m[1]));

    m = u.match(/\/chuong-(\d+(?:\.\d+)?)\/?/i);
    if (m && m[1]) return cleanText(m[1]);

    m = u.match(/\/tap-(\d+(?:\.\d+)?)\/?/i);
    if (m && m[1]) return cleanText(m[1]);

    return "";
}

function extractChapterNameFromText(text) {
    let t = cleanText(text);
    if (!t) return "";

    let m = t.match(/(?:Chuong|Chương|Chapter)\s*(\d+(?:\.\d+)?)/i);
    if (m && m[1]) return m[1];

    m = t.match(/(?:Tap|Tập)\s*(\d+(?:\.\d+)?)/i);
    if (m && m[1]) return m[1];

    return normalizeChapterNumber(t);
}

function normalizeChapterNumber(text) {
    let m = cleanText(text).match(/\d+(?:\.\d+)?/);
    return m && m[0] ? m[0] : "";
}

function isLikelyImageUrl(url) {
    let u = cleanText(url).toLowerCase();
    if (!u) return false;

    if (/drive\.google\.com\/file\//i.test(u)) return true;
    if (/drive\.google\.com\/drive-viewer\//i.test(u)) return true;
    if (/drive\.usercontent\.google\.com\/uc\?/i.test(u)) return true;
    if (/\.(jpg|jpeg|png|gif|webp|avif)(\?|#|$)/i.test(u)) return true;
    if (/img\./i.test(u)) return true;
    if (/resourcehub/i.test(u)) return true;

    return false;
}

function isNoiseImage(url) {
    let u = cleanText(url).toLowerCase();
    if (!u) return true;

    if (/logo-chuan\./i.test(u)) return true;
    if (/googleads|doubleclick|analytics|beacon/i.test(u)) return true;
    if (/wp-content\/uploads\/.*\/(logo|icon)/i.test(u)) return true;

    return false;
}

function normalizeUrlByReferer(url, refererUrl) {
    let u = cleanText(url);
    if (!u) return "";

    if (u.indexOf("//") === 0) return "https:" + u;
    if (/^https?:\/\//i.test(u)) return u;

    let referer = cleanText(refererUrl);
    if (!referer || !/^https?:\/\//i.test(referer)) {
        return normalizeUrl(u);
    }

    let root = referer.match(/^(https?:\/\/[^\/]+)/i);
    let origin = root && root[1] ? root[1] : BASE_URL.replace(/\/$/, "");

    if (u.charAt(0) === "/") return origin + u;

    let baseDir = referer.replace(/[?#].*$/, "").replace(/\/[^\/]*$/, "/");
    return baseDir + u;
}

function normalizeUrl(url) {
    let u = cleanText(url);
    if (!u) return "";

    if (u.indexOf("//") === 0) return "https:" + u;
    if (/^https?:\/\//i.test(u)) return u;

    let base = BASE_URL.replace(/\/$/, "");
    if (u.charAt(0) === "/") return base + u;
    return base + "/" + u;
}

function buildImageUrl(domain, chapterPath, file) {
    let d = cleanText(domain || "").replace(/\/+$/, "");
    let p = cleanText(chapterPath || "").replace(/^\/+/, "").replace(/\/+$/, "");
    let f = cleanText(file || "").replace(/^\/+/, "");
    if (!p || !f) return "";

    if (d) return d + "/" + p + "/" + f;
    return "https://sv1.otruyencdn.com/" + p + "/" + f;
}

function toNumber(value, fallback) {
    let n = parseFloat(value);
    if (isNaN(n)) return fallback;
    return n;
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (e) {
        return text;
    }
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}

function cleanTextRaw(text) {
    if (!text) return "";
    return ("" + text).trim();
}
