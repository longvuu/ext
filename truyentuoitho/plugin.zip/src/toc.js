load('config.js');

function execute(url) {
    let slug = extractSlug(url);
    if (!slug) {
        slug = extractSlugFromHtml(url);
    }

    if (!slug) {
        return Response.error("Khong lay duoc slug truyen");
    }

    let chapterEndpoint = buildChapterEndpoint(url, slug);
    let doc = loadChapterDocument(chapterEndpoint, url);
    if (!doc) {
        return Response.error("Khong tai duoc danh sach chuong");
    }

    let chapters = [];
    let seen = {};

    let links = doc.select("li.wp-manga-chapter a[href], .listing-chapters_wrap a[href]");
    links.forEach(function (a) {
        let href = normalizeUrl(a.attr("href") || "");
        let chapterNumber = extractChapterNumber(href) || extractChapterNumber(a.text()) || extractChapterNumber(a.attr("title") || "");
        if (!chapterNumber) return;

        let name = cleanText(a.text()) || cleanText(a.attr("title"));
        if (!name) {
            name = "Chuong " + chapterNumber;
        }

        if (seen[href]) return;
        seen[href] = true;

        chapters.push({
            order: toNumber(chapterNumber, chapters.length + 1),
            name: name,
            url: href
        });
    });

    chapters.sort(function (a, b) {
        if (a.order !== b.order) return a.order - b.order;
        return a.url.localeCompare(b.url);
    });

    let result = [];
    chapters.forEach(function (chapter) {
        result.push({
            name: chapter.name,
            url: chapter.url,
            host: BASE_URL
        });
    });

    if (!result.length) {
        return Response.error("Khong tim thay danh sach chuong");
    }

    return Response.success(result);
}

function buildChapterEndpoint(url, slug) {
    let u = cleanText(url);
    if (/\/ajax\/chapters\//i.test(u)) {
        return u;
    }
    return normalizeUrl("/manga/" + slug + "/ajax/chapters/?t=1");
}

function loadChapterDocument(endpoint, refererUrl) {
    try {
        let response = fetch(endpoint, {
            method: "POST",
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': refererUrl || BASE_URL,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        if (response && response.ok) {
            return response.html();
        }
    } catch (error) {
    }

    try {
        let browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.chrome());
        browser.launch(endpoint, 12);
        browser.callJs("", 1500);
        let doc = browser.html();
        try { browser.close(); } catch (closeError) {}
        return doc;
    } catch (error) {
    }

    try {
        let fallback = fetch(endpoint, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': refererUrl || BASE_URL,
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        if (fallback && fallback.ok) {
            return fallback.html();
        }
    } catch (error) {
    }

    return null;
}

function extractSlug(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/manga\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/ajax\/chapters\//i);
    if (m) {
        let parts = u.match(/\/manga\/([^\/?#]+)\/ajax\/chapters/i);
        if (parts && parts[1]) return cleanText(decodeURIComponentSafe(parts[1]));
    }

    return "";
}

function extractSlugFromHtml(url) {
    if (!url) return "";

    try {
        let response = fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': BASE_URL
            }
        });
        if (!response || !response.ok) return "";

        let doc = response.html();
        let canonical = doc.select("link[rel='canonical']").attr("href") || "";
        let fromCanonical = extractSlug(canonical);
        if (fromCanonical) return fromCanonical;

        let ogUrl = doc.select("meta[property='og:url']").attr("content") || "";
        return extractSlug(ogUrl);
    } catch (error) {
        return "";
    }
}

function extractChapterNumber(text) {
    let value = cleanText(text);
    if (!value) return "";

    let match = value.match(/\/chuong-(\d+(?:\.\d+)?)/i);
    if (match && match[1]) return match[1];

    match = value.match(/\/chapter-(\d+(?:\.\d+)?)/i);
    if (match && match[1]) return match[1];

    match = value.match(/(?:Chương|Chuong|Chapter)\s*(\d+(?:\.\d+)?)/i);
    if (match && match[1]) return match[1];

    match = value.match(/\/tap-(\d+(?:\.\d+)?)/i);
    if (match && match[1]) return match[1];

    match = value.match(/(?:Tập|Tap)\s*(\d+(?:\.\d+)?)/i);
    if (match && match[1]) return match[1];

    match = value.match(/(\d+(?:\.\d+)?)/);
    return match && match[1] ? match[1] : "";
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (error) {
        return text;
    }
}

function normalizeUrl(url) {
    if (!url) return "";
    url = ("" + url).trim();
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;

    let base = BASE_URL.replace(/\/$/, "");
    if (url.indexOf("/") === 0) return base + url;
    return base + "/" + url;
}

function toNumber(value, fallback) {
    let number = parseFloat(value);
    if (isNaN(number)) return fallback;
    return number;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}