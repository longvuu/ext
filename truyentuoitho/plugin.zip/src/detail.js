load('config.js');

function execute(url) {
    let doc = loadDocument(url);
    if (!doc) {
        return Response.error("Khong tai duoc trang chi tiet");
    }

    let slug = extractSlug(url) || extractSlug(doc.select("link[rel='canonical']").attr("href") || "") || extractSlug(doc.select("meta[property='og:url']").attr("content") || "");
    if (!slug) {
        return Response.error("Khong lay duoc slug truyen");
    }

    let name = cleanText(doc.select(".post-title h1").text());
    if (!name) {
        name = cleanText(doc.select("meta[property='og:title']").attr("content") || "");
    }
    if (!name) {
        name = cleanText(slug.replace(/-/g, " "));
    }

    let cover = "";
    let coverNode = doc.select(".summary_image img").first();
    if (coverNode) {
        cover = coverNode.attr("src") || coverNode.attr("data-src") || coverNode.attr("data-lazy-src") || "";
    }
    if (!cover) {
        cover = doc.select("meta[property='og:image']").attr("content") || "";
    }
    cover = normalizeUrl(cover);

    let author = cleanText(doc.select(".author-content a").text());
    if (!author) {
        author = extractItemValueByHeading(doc, ["Tác Giả", "Tác giả", "Author"]);
    }
    if (!author) {
        author = "Đang cập nhật";
    }

    let description = cleanText(stripHtml(doc.select(".description-summary .summary__content").html() || ""));
    if (!description) {
        description = cleanText(doc.select("meta[name='description']").attr("content") || doc.select("meta[property='og:description']").attr("content") || "");
    }

    let statusText = cleanText(doc.select(".post-status .summary-content").text());
    if (!statusText) {
        statusText = extractItemValueByHeading(doc, ["Trạng thái", "Status"]);
    }
    let ongoing = !/completed|hoàn thành|full|finished/i.test(statusText) && /ongoing|đang|updating/i.test(statusText || "OnGoing");

    let genres = [];
    let seen = {};
    let genreLinks = doc.select(".genres-content a, a[href*='/manga-genre/']");
    genreLinks.forEach(function (a) {
        let title = cleanText(a.text()) || cleanText(a.attr("title"));
        if (!title) return;

        let href = normalizeUrl(a.attr("href") || "");
        let key = href || title;
        if (seen[key]) return;
        seen[key] = true;

        genres.push({
            title: title,
            input: href,
            script: "source.js"
        });
    });

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        ongoing: ongoing,
        host: BASE_URL,
        genres: genres
    });
}

function loadDocument(url) {
    if (!url) return null;

    try {
        let response = fetch(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
                'Referer': BASE_URL
            }
        });
        if (response && response.ok) {
            return response.html();
        }
    } catch (error) {
    }

    try {
        let browser = Engine.newBrowser();
        browser.setUserAgent(UserAgent.chrome());
        browser.launch(url, 12);
        browser.callJs("", 2000);
        let doc = browser.html();
        try { browser.close(); } catch (closeError) {}
        return doc;
    } catch (error) {
        return null;
    }
}

function extractItemValueByHeading(doc, headings) {
    let items = doc.select(".post-content_item");
    for (let i = 0; i < items.size(); i++) {
        let item = items.get(i);
        let heading = cleanText(item.select(".summary-heading h5").text());
        if (!heading) continue;

        for (let j = 0; j < headings.length; j++) {
            if (heading.toLowerCase() === headings[j].toLowerCase()) {
                return cleanText(item.select(".summary-content").text());
            }
        }
    }
    return "";
}

function extractSlug(url) {
    let u = cleanText(url);
    if (!u) return "";

    let m = u.match(/\/manga\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/v1\/api\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    m = u.match(/\/truyen-tranh\/([^\/?#]+)/i);
    if (m && m[1]) return cleanText(decodeURIComponentSafe(m[1]));

    return "";
}

function decodeURIComponentSafe(text) {
    try {
        return decodeURIComponent(text);
    } catch (error) {
        return text;
    }
}

function stripHtml(html) {
    if (!html) return "";
    return ("" + html).replace(/<[^>]*>/g, " ");
}

function normalizeUrl(url) {
    if (!url) return "";
    url = ("" + url).trim();
    if (!url) return "";
    if (url.indexOf("//") === 0) return "https:" + url;
    if (url.indexOf("http") === 0) return url;

    let base = BASE_URL.replace(/\/$/, "");
    if (url.indexOf("/") === 0) return base + url;
    return base + "/" + url;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}