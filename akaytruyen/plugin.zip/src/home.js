function execute() {
    return Response.success([
            {title: "Truyện", input: "https://akaytruyen.com/", script:"source.js"},
    ]);
}