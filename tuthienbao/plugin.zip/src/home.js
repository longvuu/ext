load('config.js');

function execute() {
    return Response.success([
        { title: "Danh Sach Truyen", input: "http://tuthienbao.com/forum/forumdisplay.php?f=27", script: "source.js" }
    ]);
}