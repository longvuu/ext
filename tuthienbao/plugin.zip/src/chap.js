load('config.js');

function execute(url) {
    var targetUrl = normalizeUrl(url);

    if (isImageUrl(targetUrl)) {
        return Response.success([targetUrl]);
    }

    var response = fetch(targetUrl);
    if (!response || !response.ok) {
        return Response.error('Khong tai duoc noi dung chap');
    }

    var doc = response.html();
    var images = [];
    var seen = {};

    var nodes = getContentNodes(doc);
    for (var i = 0; i < nodes.length; i++) {
        collectImagesFromNode(nodes[i], images, seen);
        if (images.length >= 3) break;
    }

    if (!images.length) {
        return Response.error('Khong tim thay anh trong chap');
    }

    images = keepLikelyComicPages(images);
    images = keepPrimaryImageCluster(images);
    if (!images.length) {
        return Response.error('Khong tim thay anh hop le trong chap');
    }

    return Response.success(images);
}

function collectImagesFromNode(node, images, seen) {
    if (!node) return;

    node.select('img').forEach(function (img) {
        var src = normalizeUrl(img.attr('data-src') || img.attr('data-original') || img.attr('src'));
        pushImage(images, seen, src);
    });

    node.select("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.png'], a[href$='.gif'], a[href$='.webp']").forEach(function (a) {
        pushImage(images, seen, normalizeUrl(a.attr('href')));
    });

    var html = node.html() || '';
    var reg = /https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|gif|webp)(?:\?[^\s"'<>]*)?/ig;
    var m;
    while ((m = reg.exec(html)) !== null) {
        pushImage(images, seen, m[0]);
    }
}

function getContentNodes(doc) {
    var nodes = [];
    var seen = {};

    function push(node) {
        if (!node) return;
        var key = '' + node;
        if (seen[key]) return;
        seen[key] = true;
        nodes.push(node);
    }

    push(doc.select("div[id^='post_message_']").first());
    doc.select("td[id^='td_post_'] div[id^='post_message_']").forEach(function (n) { push(n); });
    doc.select("td[id^='td_post_']").forEach(function (n) { push(n); });
    push(doc.select('.postcontent, .content, .quotecontent').first());

    return nodes;
}

function keepLikelyComicPages(images) {
    if (!images || images.length === 0) return [];

    var strict = [];
    images.forEach(function (u) {
        var s = (u || '').toLowerCase();
        if (/\/s\d+\/\d{1,4}\.(?:jpg|jpeg|png|webp|gif)(?:\?.*)?$/i.test(s) || /\/\d{1,4}\.(?:jpg|jpeg|png|webp|gif)(?:\?.*)?$/i.test(s)) {
            strict.push(u);
        }
    });

    if (strict.length >= 5) return strict;
    return images;
}

function keepPrimaryImageCluster(images) {
    if (!images || images.length <= 3) return images || [];

    var groups = {};
    images.forEach(function (u) {
        var key = getDirectoryKey(u);
        if (!groups[key]) groups[key] = [];
        groups[key].push(u);
    });

    var bestKey = '';
    var bestCount = 0;
    for (var k in groups) {
        if (!groups.hasOwnProperty(k)) continue;
        var c = groups[k].length;
        if (c > bestCount) {
            bestCount = c;
            bestKey = k;
        }
    }

    if (bestKey && bestCount >= 3 && bestCount >= Math.ceil(images.length * 0.5)) {
        return groups[bestKey];
    }

    return images;
}

function getDirectoryKey(url) {
    var u = (url || '').split('#')[0].split('?')[0];
    var i = u.lastIndexOf('/');
    if (i <= 0) return u;
    return u.slice(0, i).toLowerCase();
}

function pushImage(arr, seen, url) {
    var u = cleanImageUrl(url);
    if (!u || !isImageUrl(u)) return;
    if (seen[u]) return;
    seen[u] = true;
    arr.push(u);
}

function getMainPostNode(doc) {
    var post = doc.select("div[id^='post_message_']").first();
    if (post) return post;

    post = doc.select('.postcontent, .content').first();
    if (post) return post;

    var cells = doc.select('td.alt1');
    for (var i = 0; i < cells.size(); i++) {
        var td = cells.get(i);
        var txt = cleanText(td.text());
        if (!txt || txt.length < 80) continue;
        if (/powered by|tuthienbao\.com/i.test(txt)) continue;
        return td;
    }

    return null;
}

function isImageUrl(url) {
    return /\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i.test(url || '');
}

function cleanImageUrl(url) {
    var u = normalizeUrl(url);
    if (!u) return '';
    if (isBlockedImageUrl(u)) return '';
    return u.replace(/\s/g, '');
}

function isBlockedImageUrl(url) {
    var u = (url || '').toLowerCase();
    if (!u) return true;

    if (/shopee|popcash|doubleclick|googlesyndication|google-analytics|facebook|fbcdn|zalo|adservice|banner/i.test(u)) {
        return true;
    }

    if (/\/images\/tet\/|\/statusicon\/|\/buttons\/|\/icons\//i.test(u)) {
        return true;
    }

    if (/logo|icon|avatar|thumb|button|sprite|tracking|pixel|analytics|quang\s?cao|ads?/i.test(u)) {
        return true;
    }

    return false;
}

function normalizeUrl(url) {
    var u = cleanText(url);
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'http:' + u;

    var base = ('' + BASE_URL).replace(/\/+$/, '');
    if (u.charAt(0) === '/') return base + u;
    return base + '/' + u;
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
