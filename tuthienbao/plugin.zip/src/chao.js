load('config.js');

function execute(url) {
    var targetUrl = normalizeUrl(url);

    if (isImageUrl(targetUrl)) {
        return Response.success([targetUrl]);
    }

    var response = fetch(targetUrl);
    if (!response || !response.ok) {
        return Response.error('Khong tai duoc noi dung chap');
    }

    var doc = response.html();
    var pages = [];
    var seen = {};

    var nodes = getContentNodes(doc);
    for (var i = 0; i < nodes.length; i++) {
        collectImagesFromNode(nodes[i], pages, seen);
        if (pages.length >= 3) break;
    }

    if (!pages.length) {
        return Response.error('Khong tim thay anh trong chap');
    }

    pages = keepLikelyComicPages(pages);
    pages = keepPrimaryImageCluster(pages);
    if (!pages.length) {
        return Response.error('Khong tim thay anh hop le trong chap');
    }

    pages.sort(comparePageUrl);

    var result = [];
    pages.forEach(function (it) {
        result.push(it.url);
    });

    return Response.success(result);
}

function keepPrimaryImageCluster(pages) {
    if (!pages || pages.length <= 3) return pages || [];

    var groups = {};
    pages.forEach(function (it) {
        var key = getDirectoryKey(it.url);
        if (!groups[key]) groups[key] = [];
        groups[key].push(it);
    });

    var bestKey = '';
    var bestCount = 0;
    for (var k in groups) {
        if (!groups.hasOwnProperty(k)) continue;
        var c = groups[k].length;
        if (c > bestCount) {
            bestCount = c;
            bestKey = k;
        }
    }

    // Keep dominant folder only when there is a clear majority.
    if (bestKey && bestCount >= 3 && bestCount >= Math.ceil(pages.length * 0.5)) {
        return groups[bestKey];
    }

    return pages;
}

function getDirectoryKey(url) {
    var u = (url || '').split('#')[0].split('?')[0];
    var i = u.lastIndexOf('/');
    if (i <= 0) return u;
    return u.slice(0, i).toLowerCase();
}

function collectImagesFromNode(node, pages, seen) {
    if (!node) return;

    // index1: each page commonly appears as <a href=".../001.jpg"><img src=".../001.jpg"></a>
    node.select('a[href]').forEach(function (a) {
        pushPage(pages, seen, a.attr('href'));

        var img = a.select('img').first();
        if (img) {
            pushPage(pages, seen, img.attr('data-src') || img.attr('data-original') || img.attr('src'));
        }
    });

    // Extra safety in case some pages are plain <img> without anchor.
    node.select('img').forEach(function (img) {
        pushPage(pages, seen, img.attr('data-src') || img.attr('data-original') || img.attr('src'));
    });

    // Fallback parse directly from html block.
    var html = node.html() || '';
    var reg = /https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|gif|webp)(?:\?[^\s"'<>]*)?/ig;
    var m;
    while ((m = reg.exec(html)) !== null) {
        pushPage(pages, seen, m[0]);
    }
}

function getContentNodes(doc) {
    var nodes = [];
    var seen = {};

    function push(node) {
        if (!node) return;
        var key = '' + node;
        if (seen[key]) return;
        seen[key] = true;
        nodes.push(node);
    }

    push(doc.select("div[id^='post_message_']").first());
    doc.select("td[id^='td_post_'] div[id^='post_message_']").forEach(function (n) { push(n); });
    doc.select("td[id^='td_post_']").forEach(function (n) { push(n); });
    push(doc.select('.postcontent, .content, .quotecontent').first());

    return nodes;
}

function keepLikelyComicPages(pages) {
    if (!pages || pages.length === 0) return [];

    var strict = [];
    pages.forEach(function (it) {
        var u = (it.url || '').toLowerCase();
        // Typical chapter page urls: .../s0/001.jpg, .../012.png
        if (/\/s\d+\/\d{1,4}\.(?:jpg|jpeg|png|webp|gif)(?:\?.*)?$/i.test(u) || /\/\d{1,4}\.(?:jpg|jpeg|png|webp|gif)(?:\?.*)?$/i.test(u)) {
            strict.push(it);
        }
    });

    // Only enforce strict mode when enough pages are present.
    if (strict.length >= 5) return strict;
    return pages;
}

function getMainPostNode(doc) {
    // vBulletin showthread body in index1: div#post_message_387520
    var post = doc.select("div[id^='post_message_']").first();
    if (post) return post;

    post = doc.select('.postcontent, .content').first();
    if (post) return post;

    return null;
}

function pushPage(arr, seen, rawUrl) {
    var u = cleanImageUrl(rawUrl);
    if (!u || !isImageUrl(u)) return;
    if (seen[u]) return;

    seen[u] = true;
    arr.push({
        url: u,
        order: extractPageOrder(u)
    });
}

function extractPageOrder(url) {
    // Works for patterns like /001.jpg, /12.png
    var m = (url || '').match(/\/(\d{1,4})(?:\.[a-z0-9]+)(?:\?.*)?$/i);
    if (m && m[1]) {
        var n = parseInt(m[1], 10);
        if (!isNaN(n)) return n;
    }

    // Secondary fallback: pick last numeric fragment in path.
    m = (url || '').match(/(\d+(?:\.\d+)?)(?!.*\d)/);
    if (m && m[1]) {
        var n2 = parseFloat(m[1]);
        if (!isNaN(n2)) return n2;
    }

    return 999999;
}

function comparePageUrl(a, b) {
    if (a.order !== b.order) return a.order - b.order;
    if (a.url < b.url) return -1;
    if (a.url > b.url) return 1;
    return 0;
}

function isImageUrl(url) {
    return /\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i.test(url || '');
}

function cleanImageUrl(url) {
    var u = normalizeUrl(url);
    if (!u) return '';
    if (isBlockedImageUrl(u)) return '';

    // Ignore local theme/icon assets from forum chrome.
    if (/\/images\//i.test(u) && !/blogger\.googleusercontent\.com|blogspot\.com|cdn\./i.test(u)) {
        return '';
    }

    return u.replace(/\s/g, '');
}

function isBlockedImageUrl(url) {
    var u = (url || '').toLowerCase();
    if (!u) return true;

    // Common ad / tracking / social sources.
    if (/shopee|popcash|doubleclick|googlesyndication|google-analytics|facebook|fbcdn|zalo|adservice|banner/i.test(u)) {
        return true;
    }

    // Forum UI assets and decorative images are not chapter pages.
    if (/\/images\/tet\/|\/statusicon\/|\/buttons\/|\/icons\//i.test(u)) {
        return true;
    }

    // Typical ad or UI filename keywords.
    if (/logo|icon|avatar|thumb|button|sprite|tracking|pixel|analytics|quang\s?cao|ads?/i.test(u)) {
        return true;
    }

    return false;
}

function normalizeUrl(url) {
    var u = cleanText(url);
    if (!u) return '';

    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'http:' + u;

    var base = ('' + BASE_URL).replace(/\/+$/, '');
    if (u.charAt(0) === '/') {
        // Avoid duplicated /forum when BASE_URL already ends with /forum and path starts with /forum/.
        if (/\/forum$/i.test(base) && /^\/forum\//i.test(u)) {
            return base.replace(/\/forum$/i, '') + u;
        }
        return base + u;
    }
    return base + '/' + u;
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
