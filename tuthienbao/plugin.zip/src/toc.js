load('config.js');

function execute(url) {
    var targetUrl = normalizeUrl(url);
    var list = [];
    var seen = {};

    // index2.html shape: forumdisplay page with rows td#td_threadtitle_* and links showthread.php?t=...
    if (isForumDisplayUrl(targetUrl)) {
        collectForumToc(targetUrl, list, seen);
    }

    // Fallback for direct showthread url or any unexpected structure.
    if (list.length === 0) {
        collectFromThreadPage(targetUrl, list, seen);
    }

    if (list.length === 0) {
        list.push({
            name: 'Noi dung',
            url: targetUrl,
            host: BASE_URL
        });
    }

    list.sort(compareTocItem);
    return Response.success(list);
}

function collectForumToc(startUrl, list, seen) {
    var pageUrl = startUrl;
    var visited = {};
    var limit = 20;
    var count = 0;

    while (pageUrl && !visited[pageUrl] && count < limit) {
        visited[pageUrl] = true;
        count += 1;

        var response = fetch(pageUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
                "Referer": BASE_URL
            }
        });
        if (!response || !response.ok) break;

        var doc = response.html();

        doc.select("td[id^='td_threadtitle_']").forEach(function (td) {
            var a = td.select("a[id^='thread_title_'], a[href*='showthread.php'][href*='t=']").first();
            if (!a) return;

            var href = normalizeThreadUrl(a.attr('href'));
            if (!isThreadUrl(href) || seen[href]) return;

            var name = cleanText(a.text());
            if (!name) return;

            seen[href] = true;
            list.push({
                name: name,
                url: href,
                host: BASE_URL
            });
        });

        if (list.length === 0) {
            doc.select("a[href*='showthread.php'][href*='t=']").forEach(function (a) {
                var href = normalizeThreadUrl(a.attr('href'));
                if (!isThreadUrl(href) || seen[href]) return;

                var name = cleanText(a.text());
                if (!name || name.length < 2) return;

                seen[href] = true;
                list.push({
                    name: name,
                    url: href,
                    host: BASE_URL
                });
            });
        }

        pageUrl = getNextForumPageUrl(doc, pageUrl);
    }
}

function collectFromThreadPage(targetUrl, list, seen) {
    var response = fetch(targetUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
            "Referer": BASE_URL
        }
    });
    if (!response || !response.ok) {
        return;
    }

    var doc = response.html();
    var node = getMainPostNode(doc);
    if (!node) return;

    node.select('a[href]').forEach(function (a) {
        var href = normalizeThreadUrl(a.attr('href'));
        if (!href || seen[href]) return;

        var text = cleanText(a.text());
        var chapterLike = /chuong|chap|chapter|tap|part|vol|episode|\d+/i.test(text);
        if (!isThreadUrl(href) && !chapterLike) return;

        seen[href] = true;
        list.push({
            name: text || ('Chuong ' + (list.length + 1)),
            url: href,
            host: BASE_URL
        });
    });
}

function getNextForumPageUrl(doc, currentUrl) {
    var nextA = doc.select("a[rel='next'][href*='forumdisplay.php?']").first();
    if (nextA) {
        var relNext = normalizeUrl(nextA.attr('href'));
        if (isForumDisplayUrl(relNext) && relNext !== currentUrl) return relNext;
    }

    var bestUrl = '';
    var currPage = extractPageNum(currentUrl);
    var bestPage = 999999;
    doc.select("a[href*='forumdisplay.php?'][href*='page=']").forEach(function (a) {
        var href = normalizeUrl(a.attr('href'));
        if (!isForumDisplayUrl(href)) return;

        var p = extractPageNum(href);
        if (!p || p <= currPage) return;
        if (p < bestPage) {
            bestPage = p;
            bestUrl = href;
        }
    });

    return bestUrl;
}

function getMainPostNode(doc) {
    var post = doc.select("div[id^='post_message_']").first();
    if (post) return post;

    post = doc.select('.postcontent, .content').first();
    if (post) return post;

    var cells = doc.select('td.alt1');
    for (var i = 0; i < cells.size(); i++) {
        var td = cells.get(i);
        var txt = cleanText(td.text());
        if (!txt || txt.length < 80) continue;
        if (/powered by|tuthienbao\.com/i.test(txt)) continue;
        return td;
    }

    return null;
}

function compareTocItem(a, b) {
    var na = extractChapterOrder(a.name, a.url);
    var nb = extractChapterOrder(b.name, b.url);
    if (na !== nb) return na - nb;

    var ua = a.url || '';
    var ub = b.url || '';
    if (ua < ub) return -1;
    if (ua > ub) return 1;
    return 0;
}

function extractChapterOrder(name, url) {
    var n = cleanText(name || '');
    var m = n.match(/(?:chuong|chap|chapter|tap|part|vol|episode)\s*(\d+(?:\.\d+)?)/i);
    if (m && m[1]) {
        var p = parseFloat(m[1]);
        if (!isNaN(p)) return p;
    }

    m = n.match(/(\d+(?:\.\d+)?)(?!.*\d)/);
    if (m && m[1]) {
        var p2 = parseFloat(m[1]);
        if (!isNaN(p2)) return p2;
    }

    m = (url || '').match(/[?&]t=(\d+)/i);
    if (m && m[1]) {
        var tid = parseInt(m[1], 10);
        if (!isNaN(tid)) return tid;
    }

    return 999999;
}

function extractPageNum(url) {
    var m = (url || '').match(/[?&]page=(\d+)/i);
    if (m && m[1]) {
        var n = parseInt(m[1], 10);
        if (!isNaN(n) && n > 0) return n;
    }
    return 1;
}

function isForumDisplayUrl(url) {
    return /\/forumdisplay\.php\?/i.test(url || '');
}

function isThreadUrl(url) {
    return /\/showthread\.php\?t=\d+/i.test(url || '');
}

function normalizeThreadUrl(url) {
    var full = normalizeUrl(url);
    if (!full) return '';

    var m = full.match(/[?&]t=(\d+)/i);
    if (!m || !m[1]) return full;

    return normalizeUrl('showthread.php?t=' + m[1]);
}

function normalizeUrl(url) {
    var u = cleanText(url);
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'http:' + u;

    var base = ('' + BASE_URL).replace(/\/+$/, '');
    if (u.charAt(0) === '/') return base + u;
    return base + '/' + u;
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
