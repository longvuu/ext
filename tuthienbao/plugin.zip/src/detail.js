load('config.js');

function execute(url) {
    var targetUrl = normalizeUrl(url);
    var response = fetch(targetUrl);
    if (!response || !response.ok) {
        return Response.error('Khong tai duoc trang chu de');
    }

    var doc = response.html();

    var name = extractTitle(doc);
    if (!name) {
        name = cleanText(doc.select("a[id^='thread_title_'], h1").first().text());
    }
    if (!name) name = 'Chu de';

    var author = cleanText(doc.select('a.bigusername, .bigusername, .smallfont a[href*="member.php?u="]').first().text());
    if (!author) {
        author = cleanText(doc.select("span[onclick*='member.php?u=']").first().text());
    }

    var contentNode = getMainPostNode(doc);
    var contentText = cleanText(contentNode ? contentNode.text() : '');
    var description = contentText;
    if (description.length > 800) description = description.slice(0, 800) + '...';

    var cover = '';
    if (contentNode) {
        cover = findFirstImageFromNode(contentNode);
    }

    return Response.success({
        name: name,
        cover: cover,
        author: author,
        description: description,
        ongoing: true,
        host: BASE_URL,
        genres: []
    });
}

function extractTitle(doc) {
    var title = cleanText(doc.select('title').text());
    if (!title) return '';

    title = title.replace(/\s*-\s*๑๑.*$/i, '');
    title = title.replace(/\s*-\s*TuThienBao.*$/i, '');
    return cleanText(title);
}

function getMainPostNode(doc) {
    var post = doc.select("div[id^='post_message_']").first();
    if (post) return post;

    post = doc.select('.postcontent, .content').first();
    if (post) return post;

    // fallback: first cell that may contain post body
    var cells = doc.select('td.alt1');
    for (var i = 0; i < cells.size(); i++) {
        var td = cells.get(i);
        var txt = cleanText(td.text());
        if (!txt || txt.length < 80) continue;
        if (/powered by|tuthienbao\.com/i.test(txt)) continue;
        return td;
    }

    return null;
}

function findFirstImageFromNode(node) {
    var img = node.select('img').first();
    if (img) {
        var src = normalizeUrl(img.attr('data-src') || img.attr('data-original') || img.attr('src'));
        if (isImageUrl(src)) return src;
    }

    var a = node.select("a[href$='.jpg'], a[href$='.jpeg'], a[href$='.png'], a[href$='.gif'], a[href$='.webp']").first();
    if (a) {
        var href = normalizeUrl(a.attr('href'));
        if (isImageUrl(href)) return href;
    }

    var html = node.html() || '';
    var m = html.match(/https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|gif|webp)/i);
    if (m && m[0]) return m[0];

    return '';
}

function isImageUrl(url) {
    return /\.(jpg|jpeg|png|gif|webp)(\?.*)?$/i.test(url || '');
}

function normalizeUrl(url) {
    var u = cleanText(url);
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'http:' + u;

    var base = ('' + BASE_URL).replace(/\/+$/, '');
    if (u.charAt(0) === '/') return base + u;
    return base + '/' + u;
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
