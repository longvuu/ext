load('config.js');

function execute(url, page) {
    var p = parseInt(page || '1', 10);
    if (!p || p < 1) p = 1;

    var targetUrl = buildPagedForumUrl(url, p);
    var response = fetch(targetUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
            "Referer": BASE_URL
        }
    });
    if (!response || !response.ok) {
        return Response.error('Khong tai duoc danh sach chu de');
    }

    var doc = response.html();
    var data = [];
    var seen = {};
    var forumData = [];
    var forumSeen = {};

    // Root forum page (f=27) contains many sub-forums. Expose them so users can drill down.
    collectForumEntries(doc, forumData, forumSeen, targetUrl);

    // index2: td[id^=td_threadtitle_] + a[id^=thread_title_]
    doc.select("td[id^='td_threadtitle_']").forEach(function (td) {
        var a = td.select("a[id^='thread_title_'], a[href*='showthread.php'][href*='t=']").first();
        if (!a) return;

        var link = normalizeThreadUrl(a.attr('href'));
        if (!isThreadUrl(link) || seen[link]) return;

        var name = cleanText(a.text());
        if (!name) return;

        // Many rows expose image/description in title attr.
        var titleAttr = cleanText(td.attr('title'));
        var cover = extractImageUrl(titleAttr);

        var authorNode = td.select('.smallfont span, .smallfont a').first();
        var author = cleanText(authorNode ? authorNode.text() : '');
        var description = '';
        if (titleAttr && !cover) description = titleAttr;
        if (author) description = (description ? description + ' | ' : '') + author;

        seen[link] = true;
        data.push({
            name: name,
            link: link,
            cover: cover,
            description: description,
            host: BASE_URL
        });
    });

    // Fallback: generic showthread links (forumdisplay f=27 latest-post uses goto=newpost&t=...)
    if (data.length === 0) {
        doc.select("a[href*='showthread.php'][href*='t=']").forEach(function (a) {
            var link = normalizeThreadUrl(a.attr('href'));
            if (!isThreadUrl(link) || seen[link]) return;

            var name = cleanText(a.text());
            if (!name || name.length < 2) return;

            seen[link] = true;
            data.push({
                name: name,
                link: link,
                cover: '',
                description: '',
                host: BASE_URL
            });
        });
    }

    // If this page is mostly a forum index, combine sub-forums + thread rows.
    if (forumData.length > 0) {
        var merged = forumData.concat(data);
        var nextForum = getNextPage(doc, p);
        return Response.success(merged, nextForum);
    }

    var next = getNextPage(doc, p);
    return Response.success(data, next);
}

function collectForumEntries(doc, out, seen, currentUrl) {
    doc.select("a[href*='forumdisplay.php?'][href*='f=']").forEach(function (a) {
        var hrefRaw = a.attr('href');
        if (!hrefRaw) return;

        var link = normalizeUrl(hrefRaw);
        var m = link.match(/[?&]f=(\d+)/i);
        if (!m || !m[1]) return;

        var id = m[1];
        var key = 'f=' + id;
        if (seen[key]) return;

        // Skip self-link to current forum and non-content nav links.
        if (new RegExp('[?&]f=' + id + '(?:$|&)','i').test(currentUrl || '') && link.indexOf('page=') < 0) {
            return;
        }

        var name = cleanText(a.text());
        if (!name || name.length < 3) return;
        if (/^(Trang Chu|Trang Ch\u1ee7|Go Back|Tim kiem|T\u00ecm ki\u1ebfm)$/i.test(name)) return;

        seen[key] = true;
        out.push({
            name: name,
            link: normalizeUrl('forumdisplay.php?f=' + id),
            cover: '',
            description: 'Muc truyen',
            host: BASE_URL,
            script: 'source.js'
        });
    });
}

function buildPagedForumUrl(url, page) {
    var u = normalizeUrl(url || 'forumdisplay.php?f=1435');

    if (/[?&]page=/i.test(u)) {
        return u.replace(/([?&]page=)\d+/i, '$1' + page);
    }

    return u + (u.indexOf('?') >= 0 ? '&' : '?') + 'page=' + page;
}

function getNextPage(doc, currentPage) {
    var next = '';

    doc.select("a[href*='forumdisplay.php?'][href*='page=']").forEach(function (a) {
        var href = normalizeUrl(a.attr('href'));
        var m = href.match(/[?&]page=(\d+)/i);
        if (!m || !m[1]) return;

        var n = parseInt(m[1], 10);
        if (!n || n <= currentPage) return;
        if (!next || n < parseInt(next, 10)) next = String(n);
    });

    return next;
}

function extractImageUrl(text) {
    var t = cleanText(text);
    if (!t) return '';

    var m = t.match(/https?:\/\/[^\s"'<>]+\.(?:jpg|jpeg|png|gif|webp)/i);
    if (!m || !m[0]) return '';
    return m[0];
}

function isThreadUrl(url) {
    return /\/showthread\.php\?t=\d+/i.test(url || '');
}

function normalizeThreadUrl(url) {
    var full = normalizeUrl(url);
    if (!full) return '';

    var m = full.match(/[?&]t=(\d+)/i);
    if (!m || !m[1]) return full;

    // Canonical link avoids goto/newpost params and keeps parser stable.
    var id = m[1];
    var root = normalizeUrl('showthread.php?t=' + id);
    return root;
}

function normalizeUrl(url) {
    var u = cleanText(url);
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'http:' + u;

    var base = ('' + BASE_URL).replace(/\/+$/, '');
    if (u.charAt(0) === '/') return base + u;
    return base + '/' + u;
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
