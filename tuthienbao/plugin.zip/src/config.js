let BASE_URL = "http://tuthienbao.com/forum/";
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}