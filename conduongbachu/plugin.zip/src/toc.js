load('config.js');

function execute(url) {
    // Normalize base story URL (strip any existing ?page=N)
    const baseUrl = url.replace(/\?page=\d+/, '');

    // Fetch first page to determine pagination
    const firstRes = fetch(baseUrl);
    if (!firstRes.ok) return Response.error("Cannot fetch story page");
    const firstDoc = firstRes.html();

    // Determine max page from pagination controls
    let maxPage = 1;
    
    // Option 1: read from page jump input max attribute
    const jumpInput = firstDoc.select('input.jump-input.input-paginate');
    if (jumpInput.size() > 0) {
        const maxAttr = jumpInput.attr('max');
        if (maxAttr) {
            const n = parseInt(maxAttr, 10);
            if (!isNaN(n) && n > 0) maxPage = n;
        }
    }
    
    // Option 2: find highest page number from pagination links
    if (maxPage === 1) {
        firstDoc.select('a.story-ajax-paginate').forEach(a => {
            const dataUrl = a.attr('data-url');
            if (dataUrl) {
                const match = dataUrl.match(/[?&]page=(\d+)/);
                if (match) {
                    const pageNum = parseInt(match[1], 10);
                    if (!isNaN(pageNum) && pageNum > maxPage) {
                        maxPage = pageNum;
                    }
                }
            }
        });
    }

    const chapters = [];
    const seenUrls = new Set();

    // Iterate through all pages and collect chapter links
    for (let currentPage = 1; currentPage <= maxPage; currentPage++) {
        const pageUrl = baseUrl + '?page=' + currentPage;
        const res = currentPage === 1 ? firstRes : fetch(pageUrl);
        if (!res.ok) {
            console.log("Failed to fetch page " + currentPage);
            break;
        }
        const doc = currentPage === 1 ? firstDoc : res.html();

        // Select chapter links from the main chapter list container
        const chapterLinks = doc.select('.story-detail__list-chapter--list a.chapter-link-mobile, .story-detail__list-chapter--list a.chapter-link-desktop');
        
        chapterLinks.forEach(link => {
            const href = link.attr('href');
            if (!href || seenUrls.has(href)) return;

            // Extract chapter information
            const chapterNumber = link.select('.chapter-number').text().trim();
            const chapterTitle = link.select('.chapter-title').text().trim();
            
            // Build chapter name
            let name = '';
            if (chapterNumber) {
                name = chapterNumber;
                if (chapterTitle) {
                    name += ': ' + chapterTitle;
                }
            } else if (chapterTitle) {
                name = chapterTitle;
            } else {
                // Fallback to link text
                name = link.text().trim().replace(/\s+/g, ' ');
            }

            // Extract chapter number for sorting
            let chapterNum = null;
            // Try to extract from URL first (e.g., .../3480-title)
            const urlMatch = href.match(/\/(\d+)(?:-[^\/]*)?$/);
            if (urlMatch) {
                chapterNum = parseInt(urlMatch[1], 10);
            } else {
                // Try to extract from chapter number text
                const numMatch = chapterNumber.match(/(\d+)/);
                if (numMatch) {
                    chapterNum = parseInt(numMatch[1], 10);
                }
            }

            seenUrls.add(href);
            chapters.push({
                name: name,
                url: href,
                host: BASE_URL,
                _sortNum: chapterNum
            });
        });
    }

    // Sort chapters by chapter number (ascending order - oldest first)
    chapters.sort((a, b) => {
        if (a._sortNum !== null && b._sortNum !== null) {
            return a._sortNum - b._sortNum;
        }
        if (a._sortNum !== null) return -1;
        if (b._sortNum !== null) return 1;
        // Fallback to URL comparison
        return a.url.localeCompare(b.url);
    });

    // Remove sorting helper and return clean result
    const result = chapters.map(chapter => ({
        name: chapter.name,
        url: chapter.url,
        host: chapter.host
    }));

    return Response.success(result);
}