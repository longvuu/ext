function execute() {
    return Response.success([
            {title: "Truyện Mới Đăng", input: "https://truyencom.com/truyen-moi-dang", script:"source.js"},
            {title: "Truyện Mới Cập Nhật", input: "https://truyencom.com/truyen-moi-cap-nhat", script:"source.js"},
            {title: "Truyện Hot", input: "https://truyencom.com/truyen-hot", script:"source.js"},
            {title: "Truyện Đã Hoàn Thành", input: "https://truyencom.com/truyen-full", script:"source.js"},
    ]);
}