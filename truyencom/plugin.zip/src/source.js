load("config.js");

function execute(url, page) {
    if (!page) page = '1';
    let requestUrl = url;
    if (page !== '1') {
        requestUrl = url + "/trang-" + page + "/";
    }
    
    let response = fetch(requestUrl);
    if (response.ok) {
        let doc = response.html();
        let nextPage = "";
        
        // Find next page link - look for pagination
        let nextLink = doc.select('a[title=""]:contains("»"), a:has(.glyphicon-menu-right)');
        if (nextLink && nextLink.size() > 0) {
            let href = nextLink.attr("href");
            let match = /trang-(\d+)/.exec(href);
            if (match) nextPage = match[1];
        }

        let books = [];
        
        // Parse story entries from the main story list
        let storyRows = doc.select('.list-truyen .row[itemscope]');
        
        storyRows.forEach(e => {
            // Get the story title and link
            let titleElement = e.select('.truyen-title a');
            if (titleElement && titleElement.size() > 0) {
                let name = titleElement.text().trim();
                let link = titleElement.attr("href");
                
                // Get the cover image
                let cover = "";
                let coverElement = e.select('.lazyimg');
                if (coverElement && coverElement.size() > 0) {
                    cover = coverElement.attr("data-image") || coverElement.attr("data-desk-image") || "";
                }
                
                // Get author information
                let author = "";
                let authorElement = e.select('.author [itemprop="author"]');
                if (authorElement && authorElement.size() > 0) {
                    author = authorElement.text().trim();
                } else {
                    // Fallback: look for author text in span elements with pencil icon
                    let authorSpans = e.select('.author span');
                    authorSpans.forEach(span => {
                        let spanText = span.text().trim();
                        // Skip if it contains only numbers (chapter count) or glyphicon text
                        if (spanText && !spanText.match(/^\d+\s*chương/) && !spanText.includes("glyphicon")) {
                            if (!author && spanText.length > 2) {
                                author = spanText;
                            }
                        }
                    });
                }
                
                // Get chapter count
                let chapterInfo = "";
                let chapterElement = e.select('.author:contains("chương")');
                if (chapterElement && chapterElement.size() > 0) {
                    chapterInfo = chapterElement.text().trim();
                }
                
                // Check for labels (Full, Hot, New)
                let labels = [];
                let labelElements = e.select('.label-title');
                labelElements.forEach(label => {
                    let labelClass = label.attr("class");
                    if (labelClass.includes("label-full")) labels.push("Full");
                    if (labelClass.includes("label-hot")) labels.push("Hot");
                    if (labelClass.includes("label-new")) labels.push("New");
                });
                
                // Build description
                let description = "";
                if (labels.length > 0) {
                    description += "[" + labels.join(", ") + "] ";
                }
                if (chapterInfo) {
                    description += chapterInfo;
                }
                if (author) {
                    description += " - " + author;
                }
                
                if (name && link) {
                    books.push({
                        name: name,
                        link: link,
                        cover: cover,
                        description: description.trim(),
                        host: BASE_URL,
                        author: author
                    });
                }
            }
        });

        return Response.success(books, nextPage);
    }
    return null;
}