load('config.js');

function execute(url, page) {
    let allChapters = [];
    // Lấy id_story từ url, ví dụ: https://truyencom.com/muc-than-ky.12345/
    let idMatch = url.match(/\.([0-9]+)\/?$/);
    let id_story = idMatch ? idMatch[1] : null;
    if (!id_story) return null;

    // Gọi API mới lấy danh sách chapter
    let apiUrl = `https://truyencom.com/api/chapters/${id_story}`;
    let response = fetch(apiUrl);
    if (response.ok) {
        let data = response.json();
        if (data && data.items && Array.isArray(data.items)) {
            data.items.forEach((chap, index) => {
                // Sử dụng chapter_num nếu có, nếu không thì dùng index + 1
                let chapterNum = chap.chapter_num || chap.chapter_number || (index + 1);
                
                // Tạo URL đúng định dạng với .html
                let baseUrl = url.replace(/\.([0-9]+)\/?$/, ''); // Remove .id/ from URL
                let chapterUrl = baseUrl + "/chuong-" + chapterNum + ".html";
                
                allChapters.push({
                    name: chap.chapter_name || ("Chương " + chapterNum),
                    url: chapterUrl,
                    host: "https://truyencom.com"
                });
            });
            return Response.success(allChapters);
        }
    }

    // Fallback: parse HTML nếu API lỗi
    response = fetch(url);
    if (response.ok) {
        let doc = response.html();
        doc.select("#danh-sach-chuong .list-chapter li a").forEach(e => {
            allChapters.push({
                name: e.text(),
                url: e.attr("href"),
                host: "https://truyencom.com"
            });
        });
        return Response.success(allChapters);
    }
    return null;
}