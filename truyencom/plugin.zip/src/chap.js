load('config.js');

function execute(url) {
    // Validate URL format
    if (!url || !url.includes('truyencom.com')) {
        return Response.error("URL không hợp lệ. Vui lòng kiểm tra lại URL.");
    }
    
    let response = fetch(url, {
        headers: {
            "referer": BASE_URL,
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
    });
    
    if (!response.ok) {
        return Response.error("Không thể tải nội dung chương. Vui lòng thử lại sau. Mã lỗi: " + response.status);
    }

    let doc = response.html();
    
    // Check if this is a chapter page by looking for chapter content
    let chapterContent = doc.select("#chapter-c");
    if (chapterContent.length === 0) {
        // Try alternative selectors
        chapterContent = doc.select(".chapter-c");
        if (chapterContent.length === 0) {
            return Response.error("Không tìm thấy nội dung chương. Có thể URL không đúng hoặc cấu trúc trang đã thay đổi.");
        }
    }
    
    // Get chapter title from h1 a.chapter-title
    let chapterTitle = "";
    let titleElement = doc.select("h1 a.chapter-title");
    if (titleElement.length > 0) {
        chapterTitle = titleElement.text().trim();
    } else {
        // Fallback: get from page title
        let pageTitle = doc.select("title").text();
        if (pageTitle) {
            // Extract chapter info from title
            let matches = pageTitle.match(/Chương[\s\d:]+([\s\S]*?)(?:\s+của truyện|\s*$)/i);
            if (matches) {
                chapterTitle = "Chương " + matches[1].trim();
            }
        }
    }
    
    // Get the raw HTML content from the chapter-c div
    let content = chapterContent.html();
    
    if (!content || content.trim().length < 50) {
        return Response.error("Nội dung chương quá ngắn hoặc không hợp lệ.");
    }
    
    // Clean up the content
    if (content) {
        // Replace HTML entities
        content = content.replace(/&#13;/g, '\n');
        content = content.replace(/&nbsp;/g, ' ');
        content = content.replace(/&amp;/g, '&');
        content = content.replace(/&lt;/g, '<');
        content = content.replace(/&gt;/g, '>');
        content = content.replace(/&quot;/g, '"');
        
        // Clean up excessive whitespace but preserve paragraph breaks
        content = content.replace(/\n\s*\n\s*\n/g, '\n\n');
        content = content.replace(/\s+/g, ' ');
        content = content.trim();
    }
    
    // Format final output (không thêm title)
    let finalContent = content;
    if (!finalContent || finalContent.length < 100) {
        return Response.error("Nội dung chương quá ngắn hoặc không hợp lệ.");
    }
    return Response.success(finalContent);
}