load("config.js");

function execute(url) {
    let response = fetch(url);
    if (response.ok) {
        let doc = response.html();

        // Get book title
        let name = doc.select("h1").first().text().trim();

        // Get cover image
        let cover = doc.select("img[src*='cover_large']").attr("src");
        if (!cover) {
            cover = doc.select("img[src*='cover']").first().attr("src");
        }

        // Get author
        let author = "";
        let authorLinks = doc.select("h3:contains(Tác giả:) + * a, h3:contains(Tác giả:) ~ * a");
        if (authorLinks && authorLinks.size() > 0) {
            author = authorLinks.first().text().trim();
        }

        // Get description - look for the main text content
        let description = "";
        let descElements = doc.select("p");
        if (descElements && descElements.size() > 0) {
            descElements.forEach(e => {
                let text = e.text().trim();
                if (text.length > 50 && !text.includes("chương") && !text.includes("Truyện Com")) {
                    description += text + " ";
                }
            });
        }
        
        if (!description) {
            // Fallback: try to get text from div elements
            let divElements = doc.select("div");
            if (divElements && divElements.size() > 0) {
                divElements.forEach(e => {
                    let text = e.ownText().trim();
                    if (text.length > 100 && !description) {
                        description = text;
                    }
                });
            }
        }

        // Get genres
        let genres = [];
        let genreLinks = doc.select("h3:contains(Thể loại:) + * a, h3:contains(Thể loại:) ~ * a");
        if (genreLinks && genreLinks.size() > 0) {
            genreLinks.forEach(e => {
                let genreText = e.text().trim();
                if (genreText) {
                    genres.push({
                        title: genreText,
                        input: e.attr("href"),
                        script: "source.js"
                    });
                }
            });
        }

        // Get status (check if it's completed)
        let ongoing = true; // default to ongoing
        let statusElements = doc.select("h3:contains(Trạng thái:) + *, h3:contains(Trạng thái:) ~ *");
        if (statusElements && statusElements.size() > 0) {
            let statusText = statusElements.first().text();
            ongoing = statusText.indexOf("Full") === -1;
        }

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description.trim(),
            genres: genres,
            ongoing: ongoing,
            host: BASE_URL,
        });
    }
    return null;
}