load('config.js');

function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    let response = fetch(url, {
        headers: {
            "referer": BASE_URL
        }
    });

    if (response.ok) {
        let doc = response.html();
        let data = [];
        
        // Extract images from the reading-detail box_doc section
        doc.select(".reading-detail.box_doc .page-chapter img").forEach(e => {
            let src = e.attr("src");
            if (src && src.trim()) {
                data.push(src);
            }
        });
        
        // If no images found in the main section, try alternative selectors
        if (data.length === 0) {
            // Try to get images from script variable cdn1
            let scriptText = doc.html();
            let cdn1Match = scriptText.match(/var cdn1 = '(.+?)';/);
            if (cdn1Match) {
                try {
                    let imageUrls = JSON.parse(cdn1Match[1]);
                    if (Array.isArray(imageUrls)) {
                        data = imageUrls;
                    }
                } catch (e) {
                    // If JSON parsing fails, continue with other methods
                }
            }
        }
        
        // If still no images, try the #image img selector (fallback)
        if (data.length === 0) {
            doc.select("#image img").forEach(e => {
                let src = e.attr("data-src") || e.attr("src");
                if (src && src.trim()) {
                    data.push(src);
                }
            });
        }
        
        return Response.success(data);
    }

    return null;
}