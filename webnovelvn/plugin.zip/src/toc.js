load('config.js');

function execute(url) {
    const response = fetch(url);
    if (!response.ok) return Response.error("Cannot load page");

    const doc = response.html();
    const chapters = [];
    const seenUrls = new Set();

    // Extract story slug and bookId from URL and page content
    const slugMatch = url.match(/\/truyen\/([^\/\?]+)/);
    if (!slugMatch) return Response.success([]);
    
    const slug = slugMatch[1];
    let bookId = null;
    
    // Try to find bookId from embedded JSON in script tags
    const scriptTags = doc.select("script");
    scriptTags.forEach(script => {
        const scriptContent = script.html();
        // Look for bookId in various JSON structures
        if (scriptContent.indexOf('"_id"') > -1 || scriptContent.indexOf('"bookId"') > -1) {
            // Try to extract bookId from patterns like "bookId":"xxx" or "_id":"xxx"
            const idMatch = scriptContent.match(/["'](?:_id|bookId)["']\s*:\s*["']([a-f0-9]{24})["']/);
            if (idMatch) {
                bookId = idMatch[1];
            }
        }
    });

    // If bookId found, generate chapter list based on lastChapter number
    if (bookId) {
        // Try to find total chapter count
        let totalChapters = 0;
        
        // Look for chapter count in the page
        const chapterCountEl = doc.select(".min-w-\\[20px\\] span").first();
        if (chapterCountEl) {
            const countText = chapterCountEl.text().trim();
            const countMatch = countText.match(/(\d+)/);
            if (countMatch) {
                totalChapters = parseInt(countMatch[1], 10);
            }
        }
        
        // Fallback: extract from script data
        if (totalChapters === 0) {
            scriptTags.forEach(script => {
                const scriptContent = script.html();
                const lastChMatch = scriptContent.match(/["']lastChapter["']\s*:\s*(\d+)/);
                if (lastChMatch) {
                    totalChapters = parseInt(lastChMatch[1], 10);
                }
            });
        }

        // Generate chapter URLs based on slug pattern
        if (totalChapters > 0) {
            for (let i = 1; i <= totalChapters; i++) {
                const chapterUrl = BASE_URL + "truyen/" + slug + "/chuong-" + i;
                const chapterName = "Chương " + i;
                
                chapters.push({
                    name: chapterName,
                    url: chapterUrl,
                    host: BASE_URL,
                    _sortNum: i
                });
            }
            
            // Return early with generated list
            return Response.success(chapters.map(ch => ({
                name: ch.name,
                url: ch.url,
                host: ch.host
            })));
        }
    }

    // Fallback: Parse chapter links from page
    doc.select("a[href*='/chuong-']").forEach(link => {
        const href = link.attr("href");
        if (!href || seenUrls.has(href)) return;

        let name = link.select("p").text().trim();
        if (!name) {
            name = link.text().trim();
        }
        if (!name) return;

        let chapterUrl = href;
        if (!href.startsWith("http")) {
            chapterUrl = href.startsWith("/") 
                ? BASE_URL.replace(/\/$/, "") + href 
                : BASE_URL + href;
        }

        let chapterNum = null;
        const urlMatch = href.match(/\/chuong-(\d+)/);
        if (urlMatch) {
            chapterNum = parseInt(urlMatch[1], 10);
        }

        seenUrls.add(href);
        chapters.push({
            name,
            url: chapterUrl,
            host: BASE_URL,
            _sortNum: chapterNum
        });
    });

    chapters.sort((a, b) => {
        if (a._sortNum !== null && b._sortNum !== null) {
            return a._sortNum - b._sortNum;
        }
        if (a._sortNum !== null) return -1;
        if (b._sortNum !== null) return 1;
        return a.url.localeCompare(b.url);
    });

    const result = chapters.map(chapter => ({
        name: chapter.name,
        url: chapter.url,
        host: chapter.host
    }));

    return Response.success(result);
}