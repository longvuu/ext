load("config.js");

function absoluteUrl(path) {
    if (!path) return "";
    if (path.startsWith("http")) return path;
    if (path.startsWith("/")) return BASE_URL.replace(/\/$/, "") + path;
    return BASE_URL + path;
}

function execute(url, page) {
    if (!page) page = "1";
    
    let listUrl = url || (BASE_URL + "danh-sach/truyen-moi");
    
    // Build page URL - replace or add page parameter
    if (listUrl.indexOf("page=") > -1) {
        listUrl = listUrl.replace(/([?&])page=\d+/, "$1page=" + page);
    } else {
        if (listUrl.indexOf("?") > -1) {
            listUrl += "&page=" + page;
        } else {
            listUrl += "?page=" + page;
        }
    }

    const response = fetch(listUrl);
    if (!response.ok) return Response.error("Cannot load listing page");

    const doc = response.html();
    const books = [];

    // Each item is rendered as a flex row within the grid
    doc.select(".grid .flex.flex-row.items-start.gap-4").forEach(item => {
        const linkTag = item.select("a").first();
        const link = absoluteUrl(linkTag.attr("href"));
        const img = linkTag.select("img").attr("src") || "";
        const cover = absoluteUrl(img);

        const name = item.select("p.text-sm.font-semibold").text().trim();
        const description = item.select("span.line-clamp-2").text().trim();

        // Meta blocks: first block has author + chapters, second has genre
        const metaBlocks = item.select(".text-xs");
        let author = "";
        let lastChapter = "";
        let genre = "";

        if (metaBlocks.size() > 0) {
            const firstBlock = metaBlocks.get(0);
            author = firstBlock.select("a span").text().trim();
            const chapterText = firstBlock.select("span").last().text();
            const match = chapterText.match(/(\d+)/);
            if (match) {
                lastChapter = match[1];
            }
        }

        if (metaBlocks.size() > 1) {
            const secondBlock = metaBlocks.get(1);
            genre = secondBlock.select("span").last().text().trim();
        }

        books.push({
            name,
            link,
            cover,
            description,
            author,
            detail: link,
            host: BASE_URL,
            ongoing: null,
            lastChapter,
            genre
        });
    });

    // Return next page number if there are books (simple approach)
    let nextPage = "";
    if (books.length > 0) {
        nextPage = String(parseInt(page) + 1);
    }

    return Response.success(books, nextPage);
}