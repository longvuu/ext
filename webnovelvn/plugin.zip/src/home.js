function execute() {
    return Response.success([
                {title: "Truyện mới", input: "https://webnovelvn.com/danh-sach/truyen-moi?page=1", script:"source.js"},
    ]);
}