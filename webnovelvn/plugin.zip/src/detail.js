load("config.js");

function execute(url) {
    const response = fetch(url);
    if (!response.ok) return Response.error("Cannot load detail page");

    const doc = response.html();

    // Extract title from h1
    const name = doc.select("h1.font-bold").text().trim();

    // Extract cover from the first image with aspect ratio
    let cover = "";
    const imgEl = doc.select(".aspect-\\[3\\/4\\] img").first();
    if (imgEl) {
        const srcset = imgEl.attr("srcSet") || imgEl.attr("src") || "";
        // Extract highest quality image from srcset
        if (srcset.indexOf("http") > -1) {
            const matches = srcset.match(/https?:\/\/[^\s]+/g);
            if (matches && matches.length > 0) {
                cover = matches[matches.length - 1].split(" ")[0];
            }
        }
    }
    if (!cover) {
        const metaImg = doc.select("meta[property='og:image']").attr("content");
        if (metaImg) cover = metaImg;
    }

    // Extract author from link under h1
    let author = "";
    const authorLink = doc.select("a[href*='/tac-gia/']").first();
    if (authorLink) {
        author = authorLink.select("span").text().trim();
    }

    // Extract description from the prose section
    let description = doc.select(".prose.max-w-none.whitespace-break-spaces").text().trim();
    if (!description) {
        const metaDesc = doc.select("meta[name='description']").attr("content");
        if (metaDesc) description = metaDesc;
    }

    // Extract genres from category links
    const genres = [];
    doc.select("a[href*='/danh-sach/']").forEach(a => {
        const href = a.attr("href");
        const text = a.text().trim();
        if (text && href && href.indexOf("/danh-sach/") > -1) {
            genres.push({
                title: text,
                input: BASE_URL + href,
                script: "source.js"
            });
        }
    });

    // Check status: look for "Đang ra" or "Full" badge
    let ongoing = true;
    doc.select(".border.px-2.py-1.rounded").forEach(badge => {
        const text = badge.text().trim();
        if (text.indexOf("Full") > -1 || text.indexOf("Hoàn thành") > -1) {
            ongoing = false;
        }
    });

    return Response.success({
        name,
        cover,
        author,
        description,
        genres,
        ongoing,
        host: BASE_URL
    });
}