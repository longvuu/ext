load("config.js");

function execute(url) {
    let response = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (response.ok) {
        let doc = response.html();

        // Parse JSON data once and reuse
        let mangaData = null;
        try {
            let wireElements = doc.select("[wire\\:initial-data]");
            for (let i = 0; i < wireElements.size(); i++) {
                let wireElement = wireElements.get(i);
                let dataJson = wireElement.attr("wire:initial-data");
                if (dataJson) {
                    try {
                        // Decode HTML entities properly
                        dataJson = dataJson.replace(/&quot;/g, '"')
                                          .replace(/&amp;/g, '&')
                                          .replace(/&lt;/g, '<')
                                          .replace(/&gt;/g, '>')
                                          .replace(/\\u([0-9a-fA-F]{4})/g, function(match, grp) {
                                              return String.fromCharCode(parseInt(grp, 16));
                                          });
                        
                        let jsonData = JSON.parse(dataJson);
                        if (jsonData.serverMemo && jsonData.serverMemo.data && jsonData.serverMemo.data.manga) {
                            mangaData = jsonData.serverMemo.data;
                            break; // Found the right JSON data
                        }
                    } catch (parseError) {
                        console.log("Error parsing individual JSON: " + parseError);
                        continue; // Try next element
                    }
                }
            }
        } catch (e) {
            console.log("Error finding JSON data: " + e);
        }

        // Lấy tên truyện - Get book title
        let name = "";
        if (mangaData && mangaData.manga && mangaData.manga.name) {
            name = mangaData.manga.name;
        } else {
            // Fallback to title tag
            name = doc.select("title").text();
            if (name) {
                name = name.replace(" - LXMANGA", "").replace(" | LXmanga", "").trim();
            }
        }

        // Lấy ảnh bìa - Get cover image from DOM
        let cover = "";
        // First try to get from .rounded-lg.cover element with background-image
        let coverElements = doc.select(".rounded-lg.cover");
        for (let i = 0; i < coverElements.size(); i++) {
            let coverEl = coverElements.get(i);
            let style = coverEl.attr("style");
            if (style) {
                // Extract URL from background-image: url('...')
                let match = style.match(/background-image:\s*url\(['"]?([^'")\s]+)['"]?\)/i);
                if (match && match[1]) {
                    cover = match[1];
                    break;
                }
            }
        }
        
        // Fallback to JSON data if DOM doesn't have cover
        if (!cover && mangaData && mangaData.manga && mangaData.manga.cover) {
            cover = mangaData.manga.cover;
        }
        
        // Ensure absolute URL
        if (cover && !cover.startsWith("http")) {
            let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
            cover = baseUrl + "/" + cover;
        }

        // Lấy tác giả - Get author
        let author = "";
        if (mangaData && mangaData.lxartist && mangaData.lxartist.name) {
            author = mangaData.lxartist.name;
        }

        // Lấy mô tả - Get description
        let description = "";
        if (mangaData && mangaData.manga && mangaData.manga.description) {
            // Remove HTML tags and decode entities from description
            description = mangaData.manga.description
                .replace(/<[^>]*>/g, ' ')  // Remove HTML tags
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&quot;/g, '"')
                .replace(/\s+/g, ' ')     // Replace multiple spaces with single space
                .trim();
        } else {
            // Fallback to meta description
            description = doc.select("meta[name='description']").attr("content") || 
                         doc.select("meta[property='og:description']").attr("content") || "";
        }

        // Lấy thể loại - Get genres
        let genres = [];
        if (mangaData && mangaData.lxgenres && Array.isArray(mangaData.lxgenres)) {
            mangaData.lxgenres.forEach(genreItem => {
                if (genreItem && genreItem.lxgenre_id && genreItem.lxgenre_id.name && genreItem.lxgenre_id.slug) {
                    let genreName = genreItem.lxgenre_id.name;
                    let genreSlug = genreItem.lxgenre_id.slug;
                    let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                    genres.push({
                        title: genreName,
                        input: baseUrl + "/the-loai/" + genreSlug,
                        script: "source.js"
                    });
                }
            });
        }

        // Lấy trạng thái - Get status
        let ongoing = true; // Default to ongoing
        if (mangaData && mangaData.manga && mangaData.manga.mstatus) {
            ongoing = mangaData.manga.mstatus === "ongoing";
        }

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description,
            genres: genres,
            ongoing: ongoing,
            host: BASE_URL,
        });
    }
    return null;
}