load('config.js');

function execute(url) {
    // Ensure URL uses the correct base domain
    if (!url.includes("lxmanga.blog")) {
        url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    }
    
    let response = fetch(url);
    
    if (response.ok) {
        let doc = response.html();
        var imgs = [];
        
        // Debug: Try to find all elements first
        let allDivs = doc.select("div");
        let allImgs = doc.select("img");
        
        // Method 1: Simple approach - find all elements with data-src
        doc.select("[data-src]").forEach(element => {
            let imageUrl = element.attr("data-src");
            
            if (imageUrl && imageUrl.trim() !== "" && 
                (imageUrl.includes("s3.lxmanga.xyz") || imageUrl.includes(".png") || imageUrl.includes(".jpg") || imageUrl.includes(".jpeg"))) {
                imageUrl = normalizeImageUrl(imageUrl);
                if (!imgs.includes(imageUrl)) {
                    imgs.push(imageUrl);
                }
            }
        });
        
        // Method 2: Look for lazy class specifically
        if (imgs.length === 0) {
            doc.select(".lazy").forEach(element => {
                let imageUrl = element.attr("data-src");
                
                if (imageUrl && imageUrl.trim() !== "") {
                    imageUrl = normalizeImageUrl(imageUrl);
                    if (!imgs.includes(imageUrl)) {
                        imgs.push(imageUrl);
                    }
                }
            });
        }
        
        // Method 3: Look for image-container ID
        if (imgs.length === 0) {
            doc.select("#image-container").forEach(element => {
                let imageUrl = element.attr("data-src");
                
                if (imageUrl && imageUrl.trim() !== "") {
                    imageUrl = normalizeImageUrl(imageUrl);
                    if (!imgs.includes(imageUrl)) {
                        imgs.push(imageUrl);
                    }
                }
            });
        }
        
        // Method 4: Look in all img tags
        if (imgs.length === 0) {
            doc.select("img").forEach(img => {
                let imageUrl = img.attr("src") || img.attr("data-src") || img.attr("data-lazy-src");
                
                if (imageUrl && imageUrl.trim() !== "" && 
                    (imageUrl.includes("s3.lxmanga.xyz") || imageUrl.includes(".png") || imageUrl.includes(".jpg"))) {
                    imageUrl = normalizeImageUrl(imageUrl);
                    if (!imgs.includes(imageUrl)) {
                        imgs.push(imageUrl);
                    }
                }
            });
        }
        
        // Method 5: Look in script tags for hardcoded URLs
        if (imgs.length === 0) {
            doc.select("script").forEach(script => {
                let scriptText = script.html();
                
                // Look for s3 URLs in JavaScript
                let urlMatches = scriptText.match(/https?:\/\/s3\.lxmanga\.xyz\/[^\s"']+\.(png|jpg|jpeg|gif|webp)/gi);
                if (urlMatches) {
                    urlMatches.forEach(url => {
                        if (!imgs.includes(url)) {
                            imgs.push(url);
                        }
                    });
                }
            });
        }
        
        // Sort images by number if possible
        if (imgs.length > 1) {
            imgs.sort((a, b) => {
                let aNum = extractImageNumber(a);
                let bNum = extractImageNumber(b);
                return aNum - bNum;
            });
        }
        
        // Return result
        if (imgs.length > 0) {
            return Response.success(imgs);
        } else {
            // Debug info
            return Response.error("Debug: Tìm thấy " + allDivs.size() + " divs và " + allImgs.size() + " imgs nhưng không có hình ảnh hợp lệ.");
        }
    }
    
    return Response.error("Không thể tải trang. HTTP " + response.code);
}

function normalizeImageUrl(imageUrl) {
    // Ensure full URL for images
    if (imageUrl.startsWith("//")) {
        return "https:" + imageUrl;
    } else if (imageUrl.startsWith("/")) {
        // Check if it's a relative path to S3 or to the main domain
        if (imageUrl.includes("@public")) {
            return "https://s3.lxmanga.xyz" + imageUrl;
        } else {
            return BASE_URL.replace(/\/$/, '') + imageUrl;
        }
    } else if (!imageUrl.startsWith("http")) {
        // If it's a relative path without leading slash
        return BASE_URL + imageUrl;
    }
    return imageUrl;
}

function extractImageNumber(url) {
    // Extract number from URL for sorting (e.g., /0.png -> 0, /15.png -> 15)
    let match = url.match(/\/(\d+)\.(?:jpg|jpeg|png|gif|webp)/i);
    return match ? parseInt(match[1]) : 999999;
}