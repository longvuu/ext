function execute() {
    return Response.success([
            {title: "Truyện Mới", input: "https://lxmanga.blog/danh-sach?page=1", script:"source.js"},
    ]);
}