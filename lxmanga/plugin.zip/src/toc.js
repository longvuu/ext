load('config.js');

function execute(url, page) {
    let allChapters = [];
    
    // Fetch the manga detail page
    let response = fetch(url);
    if (!response.ok) {
        return null;
    }
    
    let doc = response.html();
    
    // Method 0: Try JSON first for potential oneshot mangas
    let foundInJson = false;
    try {
        let scripts = doc.select('span[wire\\:initial-data]');
        for (let i = 0; i < scripts.size(); i++) {
            let scriptElement = scripts.get(i);
            let wireData = scriptElement.attr('wire:initial-data');
            
            if (wireData && wireData.includes('lxchapters')) {
                let jsonData = JSON.parse(wireData);
                if (jsonData.serverMemo && jsonData.serverMemo.data && jsonData.serverMemo.data.manga) {
                    let manga = jsonData.serverMemo.data.manga;
                    let slug = manga.slug;
                    
                    // Extract chapters from lxchapters array
                    if (jsonData.serverMemo.data.lxchapters && jsonData.serverMemo.data.lxchapters.length > 0) {
                        jsonData.serverMemo.data.lxchapters.forEach(chapter => {
                            allChapters.push({
                                name: chapter.name,
                                url: "/truyen/" + slug + "/" + chapter.slug,
                                host: BASE_URL
                            });
                        });
                        foundInJson = true;
                        break;
                    }
                }
            }
        }
    } catch (e) {
        // Continue to other methods
    }
    
    // If found chapters in JSON, return them (common for oneshot mangas)
    if (foundInJson && allChapters.length > 0) {
        return Response.success(allChapters);
    }
    
    // Method 1: Parse chapters from HTML structure (main method)
    // Target the chapter list container specifically - there are 2 containers with the same class
    // We need to find the one that contains "Danh sách chương" in its header
    let chapterContainers = doc.select('.justify-between.border-2.border-gray-100.dark\\:border-gray-600.p-3.bg-white.dark\\:bg-gray-900.shadow-md.rounded.dark\\:shadow-gray-900.mb-4');
    let foundChapterContainer = null;
    
    // Find the container that contains "Danh sách chương" in its header
    for (let i = 0; i < chapterContainers.size(); i++) {
        let container = chapterContainers.get(i);
        let headerText = container.select('.text-lg.font-semibold').text();
        if (headerText && (headerText.includes('Danh sách chương') || headerText.includes('chương'))) {
            foundChapterContainer = container;
            break;
        }
    }
    
    if (foundChapterContainer) {
        // Look for all chapter links within this specific container
        let chapterLinks = foundChapterContainer.select('a[href*="/truyen/"]');
        chapterLinks.forEach(link => {
            let href = link.attr('href');
            let nameSpan = link.select('span.text-ellipsis');
            
            if (href && nameSpan.size() > 0) {
                let name = nameSpan.text().trim();
                // More flexible validation - check if it's a valid chapter link structure
                if (name && isValidChapterLink(href, url)) {
                    allChapters.push({
                        name: name,
                        url: href,
                        host: BASE_URL
                    });
                }
            }
        });
    }
    
    // Method 2: If no chapters found in the specific container, try broader search for chapter links
    if (allChapters.length === 0) {
        let chapterLinks = doc.select('a[href*="/truyen/"]');
        chapterLinks.forEach(link => {
            let href = link.attr('href');
            let nameSpan = link.select('span.text-ellipsis');
            
            if (href && nameSpan.size() > 0) {
                let name = nameSpan.text().trim();
                // More flexible validation
                if (name && isValidChapterLink(href, url)) {
                    allChapters.push({
                        name: name,
                        url: href,
                        host: BASE_URL
                    });
                }
            }
        });
    }
    
    // Method 2.5: Alternative approach - look for chapter text patterns and try to construct URLs
    if (allChapters.length === 0) {
        let chapterSpans = doc.select('span.text-ellipsis');
        let mangaSlug = null;
        
        // Try to extract manga slug from current URL
        try {
            let urlParts = url.split('/');
            if (urlParts.length >= 4 && urlParts[urlParts.length - 2] === 'truyen') {
                mangaSlug = urlParts[urlParts.length - 1];
            }
        } catch (e) {
            // Continue without manga slug
        }
        
        chapterSpans.forEach(span => {
            let text = span.text().trim();
            if (text && isLikelyChapterName(text) && mangaSlug) {
                // Try to extract chapter number/slug or handle various patterns
                let chapterMatch = text.match(/(chap|chapter)\s*(\d+)/i);
                if (chapterMatch) {
                    let chapterNumber = chapterMatch[2];
                    let chapterUrl = "/truyen/" + mangaSlug + "/chap-" + chapterNumber;
                    
                    allChapters.push({
                        name: text,
                        url: chapterUrl,
                        host: BASE_URL
                    });
                } else if (text.toLowerCase().includes('oneshot')) {
                    // Handle oneshot case
                    allChapters.push({
                        name: text,
                        url: "/truyen/" + mangaSlug + "/oneshot",
                        host: BASE_URL
                    });
                } else {
                    // Try to create a generic URL from the text
                    let slug = text.toLowerCase()
                                   .replace(/[^a-z0-9\s-]/g, '')
                                   .replace(/\s+/g, '-')
                                   .replace(/-+/g, '-')
                                   .replace(/^-|-$/g, '');
                    
                    if (slug) {
                        allChapters.push({
                            name: text,
                            url: "/truyen/" + mangaSlug + "/" + slug,
                            host: BASE_URL
                        });
                    }
                }
            }
        });
    }
    
    // Method 3: Extract from JSON data as final fallback (if not already done in Method 0)
    if (allChapters.length === 0 && !foundInJson) {
        try {
            let scripts = doc.select('span[wire\\:initial-data]');
            for (let i = 0; i < scripts.size(); i++) {
                let scriptElement = scripts.get(i);
                let wireData = scriptElement.attr('wire:initial-data');
                
                if (wireData && wireData.includes('lxchapters')) {
                    let jsonData = JSON.parse(wireData);
                    if (jsonData.serverMemo && jsonData.serverMemo.data && jsonData.serverMemo.data.manga) {
                        let manga = jsonData.serverMemo.data.manga;
                        let slug = manga.slug;
                        
                        // Extract chapters from lxchapters array
                        if (jsonData.serverMemo.data.lxchapters) {
                            jsonData.serverMemo.data.lxchapters.forEach(chapter => {
                                allChapters.push({
                                    name: chapter.name,
                                    url: "/truyen/" + slug + "/" + chapter.slug,
                                    host: BASE_URL
                                });
                            });
                        }
                        break;
                    }
                }
            }
        } catch (e) {
            // Continue to final fallback
        }
    }
    
    // Method 4: Last resort - if still no chapters found, try to create a default oneshot
    if (allChapters.length === 0) {
        try {
            let urlParts = url.split('/');
            if (urlParts.length >= 4 && urlParts[urlParts.length - 2] === 'truyen') {
                let mangaSlug = urlParts[urlParts.length - 1];
                
                // Check if page title or content suggests it's a oneshot
                let pageTitle = doc.select('title').text().toLowerCase();
                let hasOneshot = pageTitle.includes('oneshot') || 
                               doc.select('*:contains("oneshot")').size() > 0 ||
                               doc.select('*:contains("Oneshot")').size() > 0;
                
                if (hasOneshot) {
                    allChapters.push({
                        name: "Oneshot",
                        url: "/truyen/" + mangaSlug + "/oneshot",
                        host: BASE_URL
                    });
                }
            }
        } catch (e) {
            // Final fallback failed
        }
    }
    
    // Remove duplicates based on URL
    let uniqueChapters = [];
    let seenUrls = new Set();
    
    allChapters.forEach(chapter => {
        if (!seenUrls.has(chapter.url)) {
            seenUrls.add(chapter.url);
            uniqueChapters.push(chapter);
        }
    });
    
    // Sort chapters if possible (try to extract chapter numbers)
    uniqueChapters.sort((a, b) => {
        let aNum = extractChapterNumber(a.name);
        let bNum = extractChapterNumber(b.name);
        
        if (aNum !== null && bNum !== null) {
            return aNum - bNum;
        }
        
        return a.name.localeCompare(b.name);
    });
    
    return Response.success(uniqueChapters);
}

function extractChapterNumber(name) {
    // Try to extract chapter number from various formats
    let patterns = [
        /Chapter\s*(\d+)/i,
        /Chương\s*(\d+)/i,
        /Chap\s*(\d+)/i,
        /Ch\s*(\d+)/i,
        /^(\d+)$/,
        /(\d+)$/
    ];
    
    for (let pattern of patterns) {
        let match = name.match(pattern);
        if (match) {
            return parseInt(match[1]);
        }
    }
    
    return null;
}

function isValidChapterLink(href, currentUrl) {
    try {
        let urlParts = href.split('/');
        let currentUrlParts = currentUrl.split('/');
        
        // Must have format /truyen/{manga-slug}/{chapter-slug}
        if (urlParts.length < 4 || urlParts[1] !== 'truyen') {
            return false;
        }
        
        // Should not be the same as current manga URL (avoid self-references)
        if (href.endsWith('/truyen') || href === currentUrl) {
            return false;
        }
        
        // Should belong to the same manga (same manga slug)
        if (currentUrlParts.length >= 4 && currentUrlParts[1] === 'truyen') {
            let currentMangaSlug = currentUrlParts[currentUrlParts.length - 1];
            let linkMangaSlug = urlParts[2];
            
            // Links should be for the same manga
            if (linkMangaSlug !== currentMangaSlug) {
                return false;
            }
        }
        
        // Should have a chapter part (4th segment)
        return urlParts.length >= 4 && urlParts[3] && urlParts[3].length > 0;
        
    } catch (e) {
        return false;
    }
}

function isLikelyChapterName(text) {
    // More flexible chapter name detection
    let lowerText = text.toLowerCase();
    
    // Common chapter patterns
    let chapterPatterns = [
        /\bchap(ter)?\s*\d+/i,
        /\bch\s*\d+/i,
        /\bchương\s*\d+/i,
        /\boneshot\b/i,
        /\bphần\s*\d+/i,
        /\btập\s*\d+/i,
        /\bep(isode)?\s*\d+/i,
        /\bpart\s*\d+/i,
        /^\d+$/,
        /\d+\s*(end|final|cuối)/i
    ];
    
    // Check against patterns
    for (let pattern of chapterPatterns) {
        if (pattern.test(text)) {
            return true;
        }
    }
    
    // Additional heuristics
    // Short text with numbers might be chapters
    if (text.length <= 20 && /\d/.test(text)) {
        return true;
    }
    
    // Text that contains common chapter keywords
    let keywords = ['chap', 'chapter', 'chương', 'oneshot', 'phần', 'tập', 'episode', 'ep', 'part'];
    for (let keyword of keywords) {
        if (lowerText.includes(keyword)) {
            return true;
        }
    }
    
    return false;
}