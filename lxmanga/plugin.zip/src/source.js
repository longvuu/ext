load("config.js");

function execute(url, page) {
    if (!page) page = '1';
    
    // Ensure proper URL format
    let requestUrl = url;
    if (url.indexOf('?') > -1) {
        // URL already has parameters, append page parameter
        requestUrl = url + "&page=" + page;
    } else {
        // URL doesn't have parameters, add page parameter
        requestUrl = url + "?page=" + page;
    }
    
    let response = fetch(requestUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return Response.error("Không thể tải trang web: " + requestUrl);
    }
    
    let doc = response.html();
    let nextPage = "";
    
    // Debug: log the request URL
    console.log("Request URL: " + requestUrl);
    console.log("BASE_URL: " + BASE_URL);
    
    // Check for next page - look for pagination links
    let currentPageNum = parseInt(page);
    let paginationLinks = doc.select("a:contains(" + (currentPageNum + 1) + ")");
    if (paginationLinks.size() > 0) {
        nextPage = (currentPageNum + 1).toString();
    }

    let books = [];
    
    // Parse manga items - based on actual HTML structure observed  
    // Look for manga containers in the grid layout
    let mangaContainers = doc.select(".w-full.relative");
    
    mangaContainers.forEach(container => {
        // Look for manga-vertical containers which contain the actual manga items
        let mangaVertical = container.select(".manga-vertical").first();
        if (!mangaVertical) return;
        
        // Find the main manga link (not chapter link) in the title area
        let titleLink = mangaVertical.select("div.p-2 a.text-ellipsis").first();
        if (!titleLink) return;
        
        let href = titleLink.attr("href");
        let name = titleLink.text();
        
        // Skip if name is empty or looks like chapter
        if (!name || name.trim() === "" || 
            href.indexOf("/chapter-") > -1 || 
            href.indexOf("/chap-") > -1) {
            return;
        }
        
        // Clean up the name - remove extra spaces and trim
        name = name.trim();
        if (name.length < 2) return; // Skip very short names
        
        // Ensure absolute URL
        if (href && !href.startsWith("http")) {
            // Remove trailing slash from BASE_URL if exists
            let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
            href = baseUrl + (href.startsWith("/") ? href : "/" + href);
        }
        
        // Try to find cover within THIS manga container specifically
        let cover = "";
        
        // Look for cover with data-bg attribute within this manga container only
        let coverElement = mangaVertical.select(".cover[data-bg]").first();
        if (coverElement) {
            let dataBg = coverElement.attr("data-bg");
            // Only accept data-bg that looks like a proper image URL 
            if (dataBg && dataBg.includes("s3.lxmanga.xyz") && !dataBg.includes("load.gif")) {
                cover = dataBg;
            }
        }
        
        // Fallback: look for any data-bg within this container if no cover found
        if (!cover) {
            let anyDataBg = mangaVertical.select("[data-bg]").first();
            if (anyDataBg) {
                let dataBg = anyDataBg.attr("data-bg");
                if (dataBg && dataBg.includes("s3.lxmanga.xyz") && !dataBg.includes("load.gif")) {
                    cover = dataBg;
                }
            }
        }
        
        // Last fallback to img tags within this manga container
        if (!cover) {
            let imgElement = mangaVertical.select("img").first();
            if (imgElement) {
                let imgSrc = imgElement.attr("src") || imgElement.attr("data-src") || "";
                if (imgSrc && !imgSrc.includes("load.gif") && !imgSrc.includes(".gif")) {
                    cover = imgSrc;
                }
            }
        }
        
        // Ensure cover is absolute URL
        if (cover && !cover.startsWith("http")) {
            let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
            cover = baseUrl + (cover.startsWith("/") ? cover : "/" + cover);
        }
        
        // Check if we already have this manga (avoid duplicates)
        let alreadyExists = false;
        for (let i = 0; i < books.length; i++) {
            if (books[i].name === name || books[i].link === href) {
                alreadyExists = true;
                break;
            }
        }
        
        if (!alreadyExists && href && name) {
            books.push({
                name: name,
                link: href,
                cover: cover,
                description: "",
                host: BASE_URL,
                author: ""
            });
        }
    });

    return Response.success(books, nextPage);
}
