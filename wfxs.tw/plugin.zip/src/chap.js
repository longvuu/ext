load("config.js");

function execute(url) {
    try {
        // Kiểm tra và sửa URL nếu cần
        let cleanUrl = url;
        if (!cleanUrl.startsWith("http")) {
            cleanUrl = BASE_URL + url;
        }
        
        let response = fetch(cleanUrl, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
                'Referer': BASE_URL,
                'Connection': 'keep-alive'
            },
            timeout: 15000
        });
        
        if (response.status == 404) {
            return Response.error("Trang không tồn tại (404)");
        }
        
        if (!response.ok) {
            return Response.error("HTTP Error: " + response.status);
        }
        
        let doc = response.html();
        
        if (!doc) {
            return Response.error("Cannot parse HTML");
        }
        
        // Extract book title với nhiều cách khác nhau
        let bookTitle = "";
        
        // Thử lấy từ title tag trước
        let titleElement = doc.select("title").first();
        if (titleElement) {
            let titleText = titleElement.text();
            if (titleText && titleText.includes(" - ")) {
                bookTitle = titleText.split(" - ")[0].trim();
            }
        }
        
        // Nếu không có, thử các selector khác
        if (!bookTitle) {
            let titleSelectors = ["h1 #ed-1", "h1", ".book-title", "h1.title"];
            for (let selector of titleSelectors) {
                let element = doc.select(selector).first();
                if (element) {
                    bookTitle = element.text().trim();
                    if (bookTitle) break;
                }
            }
        }
        
        if (!bookTitle) {
            bookTitle = "Không tìm thấy tên truyện";
        }
        
        // Extract author
        let author = "";
        let authorSelectors = [
            "h4.mytitle.bread a[href*='searchAuthor']",
            "h4.mytitle.bread a",
            ".author a",
            ".book-author",
            "meta[property='og:novel:author']"
        ];
        
        for (let selector of authorSelectors) {
            let element = doc.select(selector).first();
            if (element) {
                if (selector.includes("meta")) {
                    author = element.attr("content") || "";
                } else {
                    author = element.text().trim();
                }
                if (author) break;
            }
        }
        
        if (!author) {
            author = "Không rõ";
        }
        
        // Extract description từ meta tag
        let description = "";
        let metaDesc = doc.select("meta[property='og:description']").first();
        if (metaDesc) {
            description = metaDesc.attr("content") || "";
        }
        
        if (!description) {
            let descElements = doc.select(".description");
            if (descElements.size() > 0) {
                description = descElements.last().text().trim();
            }
        }
        
        if (!description) {
            description = "Không có mô tả";
        }
        
        // Extract status
        let status = doc.select(".updating").text().trim();
        if (!status) {
            status = "Đang cập nhật";
        }
        
        // Simple stats - không bắt buộc phải có
        let views = "0";
        let favorites = "0";
        let readers = "0";
        
        let cover = "";
        
        // Create genres
        let genres = [{
            title: "Tất cả truyện",
            input: BASE_URL + "/all/0_0_5_0.html",
            script: "source.js"
        }];
        
        // Create detailed info
        let detail = `
            <div>
                <p><strong>Tác giả:</strong> ${author}</p>
                <p><strong>Trạng thái:</strong> ${status}</p>
                <p><strong>URL:</strong> ${cleanUrl}</p>
            </div>
        `;
        
        return Response.success({
            name: bookTitle,
            cover: cover,
            author: author,
            description: description,
            genres: genres,
            detail: detail,
            ongoing: true,
            host: BASE_URL,
        });
        
    } catch (error) {
        return Response.error("Lỗi kết nối: " + error.message);
    }
}