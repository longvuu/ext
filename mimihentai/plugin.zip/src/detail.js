load("config.js");

function execute(url) {
    let response = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (response.ok) {
        let doc = response.html();

        // Parse JSON data from wire:initial-data
        let mangaData = null;
        try {
            let wireElements = doc.select("[wire\\:initial-data]");
            for (let i = 0; i < wireElements.size(); i++) {
                let wireElement = wireElements.get(i);
                let dataJson = wireElement.attr("wire:initial-data");
                if (dataJson) {
                    try {
                        // Decode HTML entities properly
                        dataJson = dataJson.replace(/&quot;/g, '"')
                                          .replace(/&amp;/g, '&')
                                          .replace(/&lt;/g, '<')
                                          .replace(/&gt;/g, '>')
                                          .replace(/\\u([0-9a-fA-F]{4})/g, function(match, grp) {
                                              return String.fromCharCode(parseInt(grp, 16));
                                          });
                        
                        let jsonData = JSON.parse(dataJson);
                        if (jsonData.serverMemo && jsonData.serverMemo.data && jsonData.serverMemo.data.manga) {
                            mangaData = jsonData.serverMemo.data;
                            break; // Found the right JSON data
                        }
                    } catch (parseError) {
                        continue; // Try next element
                    }
                }
            }
        } catch (e) {
            // Continue with HTML fallback
        }

        // Get book title
        let name = "";
        if (mangaData && mangaData.manga && mangaData.manga.name) {
            name = mangaData.manga.name;
        } else {
            // Fallback to title tag
            name = doc.select("title").text();
            if (name) {
                name = name.replace(" - ", "").replace(" | ", "").trim();
            }
        }

        // Get cover image - try multiple sources
        let cover = "";
        
        // Try 1: Get from <img> tags
        let imgTags = doc.select("img");
        for (let i = 0; i < imgTags.size(); i++) {
            let img = imgTags.get(i);
            let alt = img.attr("alt");
            let src = img.attr("src");
            let dataSrc = img.attr("data-src");
            
            // Look for cover/poster image
            if ((alt && (alt.toLowerCase().includes('cover') || alt.toLowerCase().includes('poster'))) ||
                (src && src.includes('cover'))) {
                cover = src || dataSrc;
                if (cover) break;
            }
        }
        
        // Try 2: Look for background-image style
        if (!cover) {
            let styledDivs = doc.select("div[style*='background-image']");
            for (let i = 0; i < styledDivs.size(); i++) {
                let div = styledDivs.get(i);
                let style = div.attr("style");
                if (style) {
                    // Extract URL from background-image: url('...')
                    let match = style.match(/background-image:\s*url\(['"]?([^'")\s]+)['"]?\)/i);
                    if (match && match[1]) {
                        cover = match[1];
                        break;
                    }
                }
            }
        }
        
        // Try 3: Get from JSON data
        if (!cover && mangaData && mangaData.manga && mangaData.manga.cover) {
            cover = mangaData.manga.cover;
        }
        
        // Ensure absolute URL
        if (cover && !cover.startsWith("http")) {
            let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
            cover = baseUrl + (cover.startsWith("/") ? cover : "/" + cover);
        }

        // Get author
        let author = "";
        if (mangaData && mangaData.lxartist && mangaData.lxartist.name) {
            author = mangaData.lxartist.name;
        } else if (mangaData && mangaData.artist) {
            author = mangaData.artist;
        }

        // Get description
        let description = "";
        if (mangaData && mangaData.manga && mangaData.manga.description) {
            // Remove HTML tags and decode entities
            description = mangaData.manga.description
                .replace(/<[^>]*>/g, ' ')  // Remove HTML tags
                .replace(/&lt;/g, '<')
                .replace(/&gt;/g, '>')
                .replace(/&amp;/g, '&')
                .replace(/&quot;/g, '"')
                .replace(/\s+/g, ' ')     // Replace multiple spaces
                .trim();
        } else {
            // Fallback to meta description
            description = doc.select("meta[name='description']").attr("content") || 
                         doc.select("meta[property='og:description']").attr("content") || "";
        }

        // Get genres
        let genres = [];
        if (mangaData && mangaData.lxgenres && Array.isArray(mangaData.lxgenres)) {
            mangaData.lxgenres.forEach(genreItem => {
                if (genreItem && genreItem.lxgenre_id && genreItem.lxgenre_id.name && genreItem.lxgenre_id.slug) {
                    let genreName = genreItem.lxgenre_id.name;
                    let genreSlug = genreItem.lxgenre_id.slug;
                    let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                    genres.push({
                        title: genreName,
                        input: baseUrl + "/the-loai/" + genreSlug,
                        script: "source.js"
                    });
                }
            });
        } else {
            // Try to extract genres from HTML
            let genreLinks = doc.select("a[href*='/the-loai/']");
            genreLinks.forEach(link => {
                let genreName = link.text().trim();
                let genreUrl = link.attr("href");
                if (genreName && genreUrl) {
                    genres.push({
                        title: genreName,
                        input: genreUrl,
                        script: "source.js"
                    });
                }
            });
        }

        // Get status
        let ongoing = true; // Default to ongoing
        if (mangaData && mangaData.manga && mangaData.manga.mstatus) {
            ongoing = mangaData.manga.mstatus === "ongoing" || mangaData.manga.mstatus === "Ongoing";
        }

        return Response.success({
            name: name,
            cover: cover,
            author: author,
            description: description,
            genres: genres,
            ongoing: ongoing,
            host: BASE_URL,
        });
    }
    return null;
}