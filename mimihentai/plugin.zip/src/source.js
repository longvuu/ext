load("config.js");

function execute(url, page) {
    if (!page) page = '1';
    
    // Ensure proper URL format
    let requestUrl = url;
    if (url.indexOf('?') > -1) {
        // URL already has parameters, append page parameter
        requestUrl = url + "&page=" + page;
    } else {
        // URL doesn't have parameters, add page parameter
        requestUrl = url + "?page=" + page;
    }
    
    let response = fetch(requestUrl, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return Response.error("Không thể tải trang web: " + requestUrl);
    }
    
    let doc = response.html();
    let nextPage = "";
    
    // Check for next page - look for pagination links
    let currentPageNum = parseInt(page);
    let paginationLinks = doc.select("a[href*='page=" + (currentPageNum + 1) + "']");
    if (paginationLinks.size() > 0) {
        nextPage = (currentPageNum + 1).toString();
    }

    let books = [];
    
    // Parse manga items from the grid - select anchor tags with class "group"
    let mangaLinks = doc.select("a.group");
    
    mangaLinks.forEach(mangaLink => {
        try {
            let href = mangaLink.attr("href");
            
            // Get title from h1 tag inside the link
            let titleElement = mangaLink.select("h1").first();
            let name = titleElement ? titleElement.text().trim() : "";
            
            // Skip if name is empty or invalid
            if (!name || name.length < 2) return;
            
            // Ensure absolute URL for manga link
            if (href && !href.startsWith("http")) {
                let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                href = baseUrl + (href.startsWith("/") ? href : "/" + href);
            }
            
            // Get cover image - try multiple sources
            let cover = "";
            
            // Try 1: Look for <img> tag with src attribute
            let imgTag = mangaLink.select("img").first();
            if (imgTag) {
                cover = imgTag.attr("src");
                if (!cover) {
                    cover = imgTag.attr("data-src");
                }
                if (!cover) {
                    cover = imgTag.attr("data-lazy-src");
                }
            }
            
            // Try 2: Look for style attribute with background-image
            if (!cover) {
                let coverDiv = mangaLink.select("div.w-full.h-full").first();
                if (coverDiv) {
                    let style = coverDiv.attr("style");
                    if (style) {
                        // Extract URL from background-image: url('...')
                        let match = style.match(/url\(['"](.*?)['"]\)/);
                        if (!match) {
                            // Try without quotes
                            match = style.match(/url\((.*?)\)/);
                        }
                        if (match && match[1]) {
                            cover = match[1].trim();
                        }
                    }
                }
            }
            
            // Try 3: Look for picture > source tags
            if (!cover) {
                let pictureTag = mangaLink.select("picture").first();
                if (pictureTag) {
                    let sourceTag = pictureTag.select("source").first();
                    if (sourceTag) {
                        cover = sourceTag.attr("srcset");
                        if (cover && cover.indexOf(',') > -1) {
                            // If multiple sources, take the first one
                            cover = cover.split(',')[0].trim().split(' ')[0];
                        }
                    }
                    if (!cover) {
                        let img = pictureTag.select("img").first();
                        if (img) {
                            cover = img.attr("src");
                        }
                    }
                }
            }
            
            // Ensure cover is absolute URL
            if (cover && !cover.startsWith("http")) {
                let baseUrl = BASE_URL.endsWith('/') ? BASE_URL.slice(0, -1) : BASE_URL;
                cover = baseUrl + (cover.startsWith("/") ? cover : "/" + cover);
            }
            
            // Check if we already have this manga (avoid duplicates)
            let alreadyExists = false;
            for (let i = 0; i < books.length; i++) {
                if (books[i].name === name || books[i].link === href) {
                    alreadyExists = true;
                    break;
                }
            }
            
            if (!alreadyExists && href && name) {
                books.push({
                    name: name,
                    link: href,
                    cover: cover,
                    description: "",
                    host: BASE_URL,
                    author: ""
                });
            }
        } catch (e) {
            // Skip invalid items
        }
    });

    return Response.success(books, nextPage);
}
