load('config.js');

function execute(url, page) {
    let allChapters = [];
    
    // Fetch the manga detail page
    let response = fetch(url, {
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Referer': BASE_URL,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'vi-VN,vi;q=0.9,en;q=0.8',
            'Cache-Control': 'no-cache'
        }
    });
    if (!response.ok) {
        return null;
    }
    
    let doc = response.html();
    
    // Extract manga slug from current URL
    let mangaSlug = null;
    try {
        let urlParts = url.split('/');
        if (urlParts.length >= 4 && urlParts[1] === 'truyen') {
            mangaSlug = urlParts[3]; // /truyen/{manga-slug}/...
        }
    } catch (e) {
        // Continue without manga slug
    }
    
    // Method 1: Parse chapters from HTML - look for links with proper chapter URL structure
    // Links should be: /truyen/{manga-slug}/{chapter-slug}
    let allLinks = doc.select('a[href*="/truyen/"]');
    allLinks.forEach(link => {
        let href = link.attr('href');
        let linkText = link.text().trim();
        
        if (!href || !linkText) return;
        
        // Filter out non-chapter links by text content
        let lowerText = linkText.toLowerCase();
        let badKeywords = [
            'bắt đầu đọc', 'bắt đầu', 'đọc ngay', 'đọc tiếp', 'tiếp tục',
            'start reading', 'read now', 'continue', 'more info', 'details',
            'info', 'thông tin', 'xem thêm', 'chi tiết', 'view', 'update',
            'latest', 'mới nhất', 'genre', 'thể loại', 'author', 'tác giả',
            'artist', 'họa sĩ', 'status', 'trạng thái', 'rating', 'đánh giá'
        ];
        
        let isBadLink = false;
        for (let keyword of badKeywords) {
            if (lowerText.includes(keyword)) {
                isBadLink = true;
                break;
            }
        }
        if (isBadLink) return; // Skip navigation/info links
        
        try {
            let urlParts = href.split('/');
            
            // Must have format /truyen/{manga-slug}/{chapter-slug}
            // At minimum: ['', 'truyen', 'slug', 'chapter', ...]
            if (urlParts.length < 4 || urlParts[1] !== 'truyen') {
                return; // Skip - not a truyen URL
            }
            
            // Must have a chapter slug (4th part or more)
            if (!urlParts[3] || urlParts[3] === '') {
                return; // Skip - no chapter slug
            }
            
            // If we know the manga slug, only include links for this manga
            if (mangaSlug && urlParts[2] !== mangaSlug) {
                return; // Skip - different manga
            }
            
            // Check for duplicates
            let isDuplicate = false;
            for (let i = 0; i < allChapters.length; i++) {
                if (allChapters[i].url === href) {
                    isDuplicate = true;
                    break;
                }
            }
            
            if (!isDuplicate) {
                allChapters.push({
                    name: linkText,
                    url: href,
                    host: BASE_URL
                });
            }
        } catch (e) {
            // Skip invalid URLs
        }
    });
    
    // Remove duplicates based on URL
    let uniqueChapters = [];
    let seenUrls = new Set();
    
    allChapters.forEach(chapter => {
        if (!seenUrls.has(chapter.url)) {
            seenUrls.add(chapter.url);
            uniqueChapters.push(chapter);
        }
    });
    
    // Sort chapters - try multiple strategies
    uniqueChapters.sort((a, b) => {
        // Try to extract chapter numbers
        let aNum = extractChapterNumber(a.name);
        let bNum = extractChapterNumber(b.name);
        
        // If both have valid numbers, sort numerically
        if (aNum !== null && bNum !== null) {
            return aNum - bNum;
        }
        
        // If only one has a number, prioritize it
        if (aNum !== null) return -1;
        if (bNum !== null) return 1;
        
        // Fallback: alphabetical sort
        return a.name.localeCompare(b.name);
    });
    
    // Reverse if chapters are in descending order (newest first)
    // Check if majority of chapters have descending numbers
    let descendingCount = 0;
    for (let i = 0; i < uniqueChapters.length - 1; i++) {
        let curr = extractChapterNumber(uniqueChapters[i].name);
        let next = extractChapterNumber(uniqueChapters[i + 1].name);
        if (curr !== null && next !== null && curr > next) {
            descendingCount++;
        }
    }
    
    // If more than 50% are descending, reverse the entire list
    if (descendingCount > (uniqueChapters.length - 1) / 2) {
        uniqueChapters.reverse();
    }
    
    return Response.success(uniqueChapters);
}

function extractChapterNumber(name) {
    if (!name) return null;
    
    // Normalize: remove extra spaces, convert to lowercase for matching
    let text = name.trim().replace(/\s+/g, ' ');
    
    // Pattern 1: "Chapter/Chap/Ch/Chương + number" (with optional dot)
    let patterns = [
        /\b(?:chapter|chap|ch|chương|chap.?|vol.*?ch)\s*\.?\s*(\d+(?:\.\d+)?)/i,
        /\b(?:tập|phần|tập|part|ep|episode)\s*\.?\s*(\d+(?:\.\d+)?)/i,
        /\b(\d+)\s*(?:\.|:|-|$)/,  // Standalone number at word boundary
        /^(\d+)(?:\.\d+)?$/,  // Simple number
        /(\d+(?:\.\d+)?)(?:\s|-|$)/  // Number followed by space, dash, or end
    ];
    
    for (let pattern of patterns) {
        let match = text.match(pattern);
        if (match && match[1]) {
            let num = parseFloat(match[1]);
            if (!isNaN(num)) {
                return num;
            }
        }
    }
    
    return null;
}