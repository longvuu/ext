let BASE_URL = 'https://nettruyen.org.uk';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
    }
} catch (error) {
}
