function execute() {
    return Response.success([
        {title: "Mới Cập Nhật", input: "/tim-truyen", script: "gen.js"},

    ]);
}
