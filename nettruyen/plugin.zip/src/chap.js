load('config.js');

function execute(url) {
    var targetUrl = normalizeTargetUrl(url);
    var response = fetch(targetUrl);
    if (!response || !response.ok) return null;

    var doc = response.html();
    var imgs = doc.select('.reading-detail .page-chapter img, .page-chapter img');
    var data = [];

    imgs.forEach(function (elm) {
        var candidates = [];

        pushIfValid(candidates, elm.attr('data-src'));
        pushIfValid(candidates, elm.attr('data-sv1'));
        pushIfValid(candidates, elm.attr('src'));
        pushIfValid(candidates, elm.attr('data-original'));
        pushIfValid(candidates, elm.attr('data-lazy-src'));

        var link = candidates.length ? candidates[0] : '';
        if (!link) return;

        var fallback = [];
        pushIfDifferent(fallback, elm.attr('data-sv2'), link);
        for (var i = 1; i < candidates.length; i++) {
            pushIfDifferent(fallback, candidates[i], link);
        }

        data.push({
            link: link,
            fallback: fallback
        });
    });

    return Response.success(data);
}

function normalizeTargetUrl(url) {
    var u = cleanText(url);
    if (!u) return BASE_URL;
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'https:' + u;
    if (u.charAt(0) === '/') return BASE_URL + u;
    return BASE_URL + '/' + u;
}

function pushIfValid(arr, value) {
    var v = normalizeImageUrl(value);
    if (!v) return;
    if (arr.indexOf(v) >= 0) return;
    arr.push(v);
}

function pushIfDifferent(arr, value, base) {
    var v = normalizeImageUrl(value);
    if (!v || v === base) return;
    if (arr.indexOf(v) >= 0) return;
    arr.push(v);
}

function normalizeImageUrl(url) {
    var u = cleanText(url);
    if (!u) return '';
    if (u.indexOf('//') === 0) u = 'https:' + u;
    if (u.charAt(0) === '/') u = BASE_URL + u;
    return u.split('?')[0];
}

function cleanText(text) {
    if (!text) return '';
    return ('' + text).replace(/\s+/g, ' ').trim();
}
