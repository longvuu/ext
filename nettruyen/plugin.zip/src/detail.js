load('config.js');

function execute(url) {
    var targetUrl = normalizeTargetUrl(url);
    var response = fetch(targetUrl);
    if (!response || !response.ok) return null;

    var root = response.html().select('#item-detail');
    if (!root) return null;

    var title = cleanText(root.select('h1.title-detail').text());
    var coverNode = root.select('.detail-info .col-image img').first();
    var cover = absoluteUrl(
        (coverNode && (coverNode.attr('data-src') || coverNode.attr('data-original') || coverNode.attr('src'))) || ""
    );

    var author = cleanText(root.select('.list-info li.author p:last-child').text());
    var status = cleanText(root.select('.list-info li.status p:last-child').text());
    var views = cleanText(root.select('.list-info li:has(i.fa-eye) p:last-child').text());
    if (!views) views = cleanText(root.select('.list-info li.row:last-child p:last-child').text());
    var follow = cleanText(root.select('.follow .number_follow, .follow span b').text());
    var updated = cleanText(root.select('time.small').text());

    var descHtml = root.select('.detail-content .shortened').html() || "";
    if (!descHtml) descHtml = root.select('.detail-content').html() || "";

    var genres = [];
    root.select('.list-info .kind a').forEach(function (e) {
        var gTitle = cleanText(e.text());
        var gHref = cleanText(e.attr('href'));
        if (!gTitle || !gHref) return;

        genres.push({
            title: gTitle,
            input: gHref.replace(/^https?:\/\/[^\/]+/i, ''),
            script: 'gen.js'
        });
    });

    var detailLines = [];
    if (author) detailLines.push('Tac gia: ' + author);
    if (status) detailLines.push('Tinh trang: ' + status);
    if (follow) detailLines.push('Luot theo doi: ' + follow);
    if (views) detailLines.push('Luot xem: ' + views);
    if (updated) detailLines.push('Cap nhat: ' + updated);

    var ongoing = true;
    if (/hoan thanh|full/i.test(status)) ongoing = false;

    return Response.success({
        name: title,
        cover: cover,
        host: BASE_URL,
        author: author,
        description: descHtml,
        detail: detailLines.join('<br>'),
        ongoing: ongoing,
        genres: genres
    });
}

function normalizeTargetUrl(url) {
    var u = cleanText(url);
    if (!u) return BASE_URL;
    if (/^https?:\/\//i.test(u)) {
        return u.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    }
    return absoluteUrl(u);
}

function absoluteUrl(url) {
    var u = cleanText(url);
    if (!u) return "";
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf('//') === 0) return 'https:' + u;
    if (u.charAt(0) === '/') return BASE_URL + u;
    return BASE_URL + '/' + u;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, ' ').trim();
}