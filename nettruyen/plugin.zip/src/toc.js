load('config.js');

function execute(url) {
    var targetUrl = normalizeTargetUrl(url);
    var fromApi = fetchTocFromApi(targetUrl);
    if (fromApi && fromApi.length) {
        return Response.success(fromApi);
    }

    var response = fetch(targetUrl);
    if (!response || !response.ok) return null;

    var doc = response.html();
    var list = [];
    var els = doc.select('#chapter_list li .chapter a, #nt_listchapter nav .chapter a');

    for (var i = els.size() - 1; i >= 0; i--) {
        var e = els.get(i);
        var name = cleanText(e.text());
        var href = absoluteUrl(e.attr('href') || '');
        if (!name || !href) continue;

        list.push({
            name: name,
            url: href,
            host: BASE_URL
        });
    }

    return Response.success(list);
}

function fetchTocFromApi(detailUrl) {
    var slug = getSlug(detailUrl);
    if (!slug) return [];

    var seriesBase = getSeriesBase(detailUrl, slug);
    var apiUrl = BASE_URL + '/Comic/Services/ComicService.asmx/ChapterList?slug=' + encodeURIComponent(slug);
    var apiRes = fetch(apiUrl);
    if (!apiRes || !apiRes.ok) return [];

    var json;
    try {
        json = apiRes.json();
    } catch (e) {
        return [];
    }
    if (!json || !json.data || !json.data.length) return [];

    var rows = json.data.slice();
    rows.sort(function (a, b) {
        var an = toNumber(a && a.chapter_num);
        var bn = toNumber(b && b.chapter_num);
        if (an !== bn) return an - bn;

        var aid = toNumber(a && a.chapter_id);
        var bid = toNumber(b && b.chapter_id);
        return aid - bid;
    });

    var list = [];
    rows.forEach(function (row) {
        if (!row) return;
        var chapterSlug = cleanText(row.chapter_slug || '');
        if (!chapterSlug) return;

        var chapterName = cleanText(row.chapter_name || '');
        if (!chapterName) {
            var chapterNum = cleanText(row.chapter_num);
            chapterName = chapterNum ? ('Chapter ' + chapterNum) : chapterSlug;
        }

        list.push({
            name: chapterName,
            url: seriesBase + '/' + chapterSlug,
            host: BASE_URL
        });
    });

    return list;
}

function getSlug(url) {
    var u = cleanText(url);
    if (!u) return '';
    u = u.split('?')[0].split('#')[0].replace(/\/+$/, '');
    var i = u.lastIndexOf('/');
    if (i < 0) return '';
    return cleanText(u.substring(i + 1));
}

function getSeriesBase(url, slug) {
    var u = cleanText(url || '');
    if (!u) return BASE_URL + '/truyen-tranh/' + slug;
    u = u.split('?')[0].split('#')[0].replace(/\/+$/, '');

    if (slug && u.toLowerCase().endsWith('/' + slug.toLowerCase())) return u;
    return BASE_URL + '/truyen-tranh/' + slug;
}

function toNumber(v) {
    var n = parseFloat(v);
    return isNaN(n) ? 0 : n;
}

function normalizeTargetUrl(url) {
    var u = cleanText(url);
    if (!u) return BASE_URL;
    if (/^https?:\/\//i.test(u)) {
        return u.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    }
    return absoluteUrl(u);
}

function absoluteUrl(url) {
    var u = cleanText(url);
    if (!u) return "";
    if (/^https?:\/\//i.test(u)) return u;
    if (u.indexOf("//") === 0) return "https:" + u;
    if (u.charAt(0) === "/") return BASE_URL + u;
    return BASE_URL + "/" + u;
}

function cleanText(text) {
    if (!text) return "";
    return ("" + text).replace(/\s+/g, " ").trim();
}