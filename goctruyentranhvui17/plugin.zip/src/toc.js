load('config.js');

function execute(url) {
    const base = BASE_URL.replace(/\/$/, '');

    // Fetch the story page first to extract comic id and slug
    let res = fetch(url);
    if (!res.ok) return null;
    let doc = res.html();

    // attempt to read comic id from hidden input (seen in index.html)
    let comicId = doc.select('#comic-id-comment').attr('value') || doc.select('input#comic-id-comment').attr('value');

    // extract slug from url: /truyen/<slug>
    let slug = '';
    if (url.indexOf('/truyen/') > -1) {
        slug = url.split('/truyen/')[1].replace(/\/$/, '');
        if (slug.indexOf('/') > -1) slug = slug.split('/')[0];
    }

    // If we have a comicId, call API to get full chapter list
    if (comicId) {
        try {
            // offset=0, limit=-1 to fetch all chapters
            let api = base + '/api/comic/' + comicId + '/chapter?offset=0&limit=-1';
            let r = fetch(api);
            if (r.ok) {
                let json = r.json();
                if (json && json.result && Array.isArray(json.result.chapters)) {
                    let chapters = json.result.chapters.map(ch => {
                        let num = ch.numberChapter || ch.number || '';
                        // build name — prefer '#<num>' like previous implementation
                        let name = (num ? '#' + num : (ch.name || ''));
                        // build URL using slug if available, otherwise try to use id-based URL
                        let href = '';
                        if (slug) {
                            href = base + '/truyen/' + slug + '/chuong-' + num;
                        } else if (ch.id) {
                            // fallback: try id based URL pattern if site supports it
                            href = base + '/truyen/' + comicId + '/chuong-' + num;
                        }
                        return { name: name, url: href, host: BASE_URL, _sortNum: (num ? parseFloat(num) : null) };
                    });

                    // sort ascending (oldest first)
                    chapters.sort((a, b) => {
                        if (a._sortNum !== null && b._sortNum !== null) return a._sortNum - b._sortNum;
                        if (a._sortNum !== null) return -1;
                        if (b._sortNum !== null) return 1;
                        return a.url.localeCompare(b.url);
                    });

                    return Response.success(chapters.map(c => ({ name: c.name, url: c.url, host: c.host })));
                }
            }
        } catch (e) {
            // ignore and fallback to HTML scraping
        }
    }

    // Fallback: scrape DOM (previous logic)
    // Select all chapter anchors inside the chapter list
    let links = doc.select('.chapter-list .list a');
    if (!links || links.size() === 0) links = doc.select('.list a, .chapter-list a, a[href*="/truyen/"]');

    const out = [];
    const seen = new Set();
    links.forEach(a => {
        let href = a.attr('href') || '';
        href = href.trim();
        if (!href) return;
        if (!/^https?:\/\//i.test(href)) href = href.startsWith('/') ? base + href : base + '/' + href;
        if (seen.has(href)) return;
        seen.add(href);

        let name = a.select('.chapter-info').text().trim().replace(/\s+/g, ' ');
        if (!name) name = a.text().trim().replace(/\s+/g, ' ');

        out.push({ name: name, url: href, host: BASE_URL });
    });

    return Response.success(out);
}