load('config.js');

function execute(key, page) {
    if (!key) return null;

    // The site appends a space to searchValue (e.g. "chào "), so include it to match behavior
    const raw = key + ' ';
    const encoded = encodeURIComponent(raw);

    // API pages appear to be 0-based. If caller passes a page (1-based), convert to 0-based.
    let curPage = 0;
    if (page) {
        const pnum = parseInt(page, 10);
        curPage = isNaN(pnum) ? 0 : Math.max(0, pnum - 1);
    }

    const api = BASE_URL.replace(/\/$/, '') + '/api/v2/search?p=' + curPage + '&searchValue=' + encoded + '&orders%5B%5D=recentDate';
    let res = fetch(api);
    if (!res.ok) return null;

    try {
        let json = res.json();
        if (!json || !json.result || !Array.isArray(json.result.data)) return Response.error(key);

        const data = json.result.data.map(item => {
            // resolve cover
            let photo = item.photo || '';
            let cover = '';
            if (photo) cover = photo.startsWith('http') ? photo : (BASE_URL.replace(/\/$/, '') + (photo.startsWith('/') ? photo : '/' + photo));

            // build detail link (slug from nameEn)
            let slug = item.nameEn || '';
            let link = slug ? BASE_URL.replace(/\/$/, '') + '/truyen/' + slug : '';

            return {
                name: item.name || '',
                link: link,
                cover: cover || 'https://i.postimg.cc/T2WtdmBM/5BdXa90.webp',
                description: item.description || (item.category ? item.category.join(', ') : ''),
                host: BASE_URL,
                id: item.id || ''
            };
        });

        // Determine next page: API returns result.next boolean
        let next = null;
        if (json.result.next) {
            // convert back to 1-based page for the caller
            const callerNext = (curPage + 1) + 1;
            next = callerNext.toString();
        }

        return Response.success(data, next);
    } catch (e) {
        return null;
    }
}
