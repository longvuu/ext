function execute(url) {
    const base = (typeof BASE_URL !== 'undefined' ? BASE_URL : '').replace(/\/$/, '');

    // Fetch the page first to allow HTML fallback and to try to extract ids
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();

    // Helper to build HTML from image URLs
    const imagesToHtml = (imgs) => {
        if (!imgs || imgs.length === 0) return null;
        return imgs.map(src => `<img src="${src}" style="max-width:100%;display:block;margin:8px auto;">`).join('');
    };

    // 1) Try to find a chapter id in the page (common hidden inputs / data attributes)
    let chapterId = null;
    // common places
    const selectors = [
        'input#chapter-id',
        'input[name="chapterId"]',
        'input[data-chapter-id]',
        'input[data-id]',
        'div[data-chapter-id]',
        'meta[name="chapter-id"]'
    ];
    for (let s of selectors) {
        try {
            let el = doc.select(s);
            if (el && el.size && el.size() > 0) {
                // try value or data attributes
                let v = el.attr('value') || el.attr('data-chapter-id') || el.attr('data-id') || el.attr('content');
                if (v) { chapterId = v; break; }
            }
        } catch (e) {}
    }

    // Also try to infer from URL: sometimes chapter pages include an id or numeric part
    if (!chapterId) {
        let m = url.match(/(\d{6,})/); // match long numeric ids like 0001234567
        if (m) chapterId = m[1];
    }

    // Also try to read data from hidden comment input which may include data-number or commentId
    if (!chapterId) {
        try {
            let c = doc.select('#comic-id-comment');
            if (c && c.size && c.size() > 0) {
                // data-number is chapter number, not id; keep comic id separately
                // some pages may encode chapter id in data-commentId
                let v = c.attr('data-commentId') || c.attr('data-number') || c.attr('value');
                if (v && /\d{6,}/.test(v)) chapterId = v;
            }
        } catch (e) {}
    }

    // 2) If we have a chapterId, try common API endpoints that return image lists
    if (chapterId) {
        const tryApis = [
            base + '/api/chapter/' + chapterId + '/image',
            base + '/api/chapter/' + chapterId + '/images',
            base + '/api/chapter/' + chapterId + '/pages',
            base + '/api/chapter/' + chapterId + '/page',
            base + '/api/chapter/' + chapterId,
            base + '/api/comic/' + chapterId + '/chapter',
        ];

        for (let api of tryApis) {
            try {
                let r = fetch(api);
                if (!r.ok) continue;
                // try parse JSON
                let json = null;
                try { json = r.json(); } catch (e) { json = null; }
                if (!json) continue;

                // common JSON shapes: {result: {images: [...]}} || {images: [...]} || {data: [...]} || array
                let imgs = null;
                if (Array.isArray(json)) imgs = json;
                else if (json.images && Array.isArray(json.images)) imgs = json.images;
                else if (json.result && json.result.images && Array.isArray(json.result.images)) imgs = json.result.images;
                else if (json.result && json.result.data && Array.isArray(json.result.data)) imgs = json.result.data;
                else if (json.data && Array.isArray(json.data)) imgs = json.data;

                // normalize to string URLs: items may be strings or objects with url/src
                if (imgs && imgs.length) {
                    let urls = imgs.map(it => (typeof it === 'string' ? it : (it.url || it.src || it.path || it.image || it.name || ''))).filter(u => !!u).map(u => (u.startsWith('http') ? u : (u.startsWith('/') ? base + u : base + '/' + u)));
                    let html = imagesToHtml(urls);
                    if (html) return Response.success(html);
                }
            } catch (e) {
                // ignore and try next
            }
        }
    }

    // 3) Fallback to scraping images from the HTML itself
    const imgSelectors = [
        '.main-images img',
        '.image-section img',
        '.chapter-content img',
        '.reading-content img',
        '.chapter-image img',
        '.viewer img',
        'article img',
        'img'
    ];

    for (let sel of imgSelectors) {
        try {
            let els = doc.select(sel);
            if (els && els.size && els.size() > 0) {
                let urls = [];
                els.forEach(e => {
                    let s = e.attr('data-src') || e.attr('data-original') || e.attr('src') || e.attr('data-lazy');
                    if (s) {
                        s = s.trim();
                        if (!/^https?:\/\//i.test(s)) s = s.startsWith('/') ? base + s : base + '/' + s;
                        if (urls.indexOf(s) === -1) urls.push(s);
                    }
                });
                if (urls.length) return Response.success(imagesToHtml(urls));
            }
        } catch (e) {}
    }

    // 4) As a last resort, return the raw HTML of any existing chapter container
    const containers = ['.chapter-content', '.reading-content', '.main-images', '.image-section', '#content', '.content'];
    for (let c of containers) {
        try {
            let el = doc.select(c);
            if (el && el.size && el.size() > 0) {
                let h = el.html();
                if (h && h.trim()) return Response.success(h);
            }
        } catch (e) {}
    }

    return null;
}