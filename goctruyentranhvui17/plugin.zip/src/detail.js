load("config.js");

function execute(url) {
    // Normalize base
    const base = BASE_URL.replace(/\/$/, '');

    // Try to extract slug or id from URL: /truyen/<slug>
    let slug = '';
    if (url.indexOf('/truyen/') > -1) {
        slug = url.split('/truyen/')[1].replace(/\/$/, '');
        // if there are extra path segments, keep only the first (slug)
        if (slug.indexOf('/') > -1) slug = slug.split('/')[0];
    }

    // First attempt: query the site's search API to retrieve item metadata by slug/id
    if (slug) {
        try {
            let api = base + '/api/v2/search?p=1&searchValue=' + encodeURIComponent(slug) + '&orders%5B%5D=recentDate';
            let res = fetch(api);
            if (res.ok) {
                let json = res.json();
                if (json && json.result && Array.isArray(json.result.data)) {
                    // Find best match: try exact nameEn or id match first
                    let found = json.result.data.find(i => (i.nameEn && i.nameEn === slug) || (i.id && i.id === slug));
                    if (!found) {
                        // fallback: match by slug contained in nameEn or name
                        found = json.result.data.find(i => (i.nameEn && i.nameEn.indexOf(slug) > -1) || (i.name && i.name.toLowerCase().indexOf(slug.toLowerCase()) > -1));
                    }

                    if (found) {
                        // build cover url
                        let photo = found.photo || '';
                        let cover = photo.startsWith('http') ? photo : (photo ? base + (photo.startsWith('/') ? photo : '/' + photo) : '');

                        // map status code to ongoing boolean
                        let statusCode = found.statusCode || '';
                        let ongoing = true;
                        if (statusCode) {
                            let s = statusCode.toUpperCase();
                            if (s === 'COM' || s === 'FIN' || s === 'END') ongoing = false;
                            if (s === 'PRG' || s === 'UPD' || s === 'ONGOING') ongoing = true;
                        }

                        // categories
                        let genres = found.category || [];

                        // description
                        let description = found.description || found.otherName || '';

                        let detailParts = [];
                        if (genres.length) detailParts.push('Thể loại: ' + genres.join(', '));
                        if (found.followerCount) detailParts.push('Theo dõi: ' + found.followerCount);
                        if (found.viewCount) detailParts.push('Lượt xem: ' + found.viewCount);
                        if (found.updateDate) detailParts.push('Cập nhật: ' + found.updateDate);

                        return Response.success({
                            name: found.name || '',
                            cover: cover,
                            author: found.author || '',
                            description: description,
                            detail: detailParts.join('<br>'),
                            genres: genres,
                            ongoing: ongoing,
                            host: BASE_URL,
                            id: found.id || ''
                        });
                    }
                }
            }
        } catch (e) {
            // ignore and fallback to HTML scraping
        }
    }

    // Fallback: scrape HTML detail page
    let response = fetch(url);
    if (!response.ok) return null;
    let doc = response.html();

    // Try meta tags first
    let name = doc.select('meta[property="og:title"]').attr('content') || doc.select('title').text() || doc.select('h1').text();
    let cover = doc.select('meta[property="og:image"]').attr('content') || doc.select('.book-3d img').attr('src') || doc.select('.thumb img').attr('src');
    if (cover && cover.startsWith('//')) cover = 'https:' + cover;
    if (cover && cover.indexOf('http') !== 0) cover = base + (cover.startsWith('/') ? cover : '/' + cover);

    // author
    let author = doc.select('meta[name="author"]').attr('content') || doc.select('.author a').first().text() || doc.select('.story-author').text() || doc.select('.novel_info_title i a').first().text();

    // description
    let description = doc.select('meta[property="og:description"]').attr('content') || doc.select('.intro').html() || doc.select('.story-detail__top--desc').text() || doc.select('.description').text();

    // genres — collect link texts in common places
    let genres = [];
    doc.select('.tags a, .category a, .genre a, .tag a, .info a').forEach(e => {
        let t = e.text().trim();
        if (t && genres.indexOf(t) === -1) genres.push(t);
    });

    // status/ongoing
    let statusText = doc.select('.status, .state, .story-status, .text-info').text() || '';
    let ongoing = statusText && (statusText.toLowerCase().indexOf('full') === -1 && statusText.toLowerCase().indexOf('complete') === -1 && statusText.toLowerCase().indexOf('hoàn') === -1);

    let detail = '';
    if (genres.length) detail += 'Thể loại: ' + genres.join(', ');
    if (statusText) detail += (detail ? '<br>' : '') + 'Trạng thái: ' + statusText;

    return Response.success({
        name: name || '',
        cover: cover || '',
        author: author || '',
        description: description || '',
        detail: detail,
        genres: genres,
        ongoing: !!ongoing,
        host: BASE_URL
    });
}