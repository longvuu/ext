function execute() {
    return Response.success([
            {title: "Truyện Mới Cập Nhật", input: "https://goctruyentranhvui17.com/danh-sach", script:"source.js"},
    ]);
}